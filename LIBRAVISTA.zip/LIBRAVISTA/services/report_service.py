import csv, os
from datetime import datetime
from utils.helpers import LibraryError
from database.database import query

EXPORT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "exports")

REPORTS = {
 "All Books": "SELECT book_id,isbn,title,author,category,quantity,available_quantity,shelf_number FROM books",
 "Available Books": "SELECT book_id,title,author,category,available_quantity FROM books WHERE available_quantity>0",
 "Issued Books": "SELECT br.transaction_id,b.title,br.student_id,br.issue_date,br.due_date FROM borrowings br JOIN books b USING(book_id) WHERE br.status='ISSUED'",
 "Overdue Books": "SELECT br.transaction_id,b.title,br.student_id,br.due_date FROM borrowings br JOIN books b USING(book_id) WHERE br.status='ISSUED' AND br.due_date<date('now')",
 "Students": "SELECT student_id,full_name,email,phone,department,year,status FROM students",
 "Borrowing History": "SELECT br.transaction_id,b.title,br.student_id,br.issue_date,br.due_date,br.return_date,br.fine,br.status FROM borrowings br JOIN books b USING(book_id)",
 "Fine Collection": "SELECT fine_id,transaction_id,overdue_days,fine_per_day,amount,status FROM fines",
 "Popular Books": "SELECT b.title,b.author,COUNT(*) times_borrowed FROM borrowings br JOIN books b USING(book_id) GROUP BY b.book_id ORDER BY 3 DESC",
}

def export(name, fmt="csv"):
    rows = query(REPORTS[name])
    headers = list(rows[0].keys()) if rows else ["No data"]
    os.makedirs(EXPORT_DIR, exist_ok=True)
    path = os.path.join(EXPORT_DIR, f"{name.replace(' ', '_')}_{datetime.now():%Y%m%d_%H%M%S}.{fmt}")
    if fmt == "csv":
        with open(path, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f); w.writerow(headers); w.writerows([tuple(r) for r in rows])
    else:
        try:
            from openpyxl import Workbook
        except ImportError:
            raise LibraryError("Excel export needs openpyxl: pip install -r requirements.txt")
        wb = Workbook(); ws = wb.active; ws.append(headers)
        for r in rows: ws.append(list(r))
        wb.save(path)
    return path
