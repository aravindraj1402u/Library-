from database.database import query, execute, log
from utils.helpers import to_date, today, LibraryError
from datetime import date

def get_setting(key, cast=float):
    return cast(query("SELECT value FROM settings WHERE key=?", (key,))[0]["value"])

def calc_fine(due_date, return_date=None):
    """Returns (overdue_days, fine). fine = overdue_days x fine_per_day."""
    end = to_date(return_date) if return_date else date.today()
    days = max(0, (end - to_date(due_date)).days)
    return days, days * get_setting("fine_per_day")

def pending_fine(student_id):
    """Recorded pending fines + live fines on books that are overdue right now."""
    saved = query("SELECT COALESCE(SUM(f.amount),0) t FROM fines f JOIN borrowings b USING(transaction_id) "
                  "WHERE b.student_id=? AND f.status='PENDING'", (student_id,))[0]["t"]
    live = sum(calc_fine(r["due_date"])[1] for r in
               query("SELECT due_date FROM borrowings WHERE student_id=? AND status='ISSUED'", (student_id,)))
    return saved + live

def mark_paid(fine_id, by):
    execute("UPDATE fines SET status='PAID' WHERE fine_id=?", (fine_id,))
    log(by, f"Fine #{fine_id} marked as paid")

def update_settings(values, by):
    for key, label in (("max_books", "Maximum books"), ("loan_days", "Borrowing days"), ("fine_per_day", "Fine per day")):
        try:
            if float(values[key]) < 0 or (key != "fine_per_day" and float(values[key]) < 1):
                raise ValueError
        except ValueError:
            raise LibraryError(f"{label} must be a valid positive number.")
    for key, val in values.items():
        execute("INSERT OR REPLACE INTO settings VALUES(?,?)", (key, str(val)))
    log(by, "Settings updated")
