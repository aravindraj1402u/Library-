from database.database import query

def recommend(student_id, limit=5):
    """Rule based: +3 same category, +3 same author, +1 per past loan of the book (popularity)."""
    hist = query("SELECT b.category, b.author FROM borrowings br JOIN books b USING(book_id) WHERE br.student_id=?", (student_id,))
    cats, authors = {r["category"] for r in hist}, {r["author"] for r in hist}
    mine = {r["book_id"] for r in query("SELECT book_id FROM borrowings WHERE student_id=? AND status='ISSUED'", (student_id,))}
    pop = {r["book_id"]: r["c"] for r in query("SELECT book_id, COUNT(*) c FROM borrowings GROUP BY book_id")}
    scored = []
    for b in query("SELECT * FROM books WHERE available_quantity>0"):
        if b["book_id"] in mine: continue
        score = (3 if b["category"] in cats else 0) + (3 if b["author"] in authors else 0) + pop.get(b["book_id"], 0)
        scored.append((score, b))
    scored.sort(key=lambda x: -x[0])
    return [b for _, b in scored[:limit]]
