import sqlite3
from contextlib import closing
from datetime import timedelta, date
from database.database import get_conn, query, execute, log
from services.fine_service import get_setting, calc_fine
from services.notification_service import add_notification
from utils import validators as v
from utils.helpers import LibraryError, today

def availability(quantity, available):
    if quantity == 0: return "OUT OF STOCK"
    if available == 0: return "ISSUED"
    if available <= max(1, quantity * 0.2): return "LOW STOCK"
    return "AVAILABLE"

def save_book(data, by, book_id=None):
    v.required(data, ["isbn", "title", "author", "category", "quantity", "shelf_number"])
    isbn = v.isbn(data["isbn"])
    qty = v.positive_int(data["quantity"], "Quantity")
    year = v.positive_int(data.get("publication_year") or 0, "Year")
    try:
        if book_id:
            old = query("SELECT quantity, available_quantity FROM books WHERE book_id=?", (book_id,))
            if not old: raise LibraryError("Book not found.")
            avail = max(0, old[0]["available_quantity"] + qty - old[0]["quantity"])
            execute("UPDATE books SET isbn=?,title=?,author=?,category=?,publisher=?,publication_year=?,language=?,"
                    "quantity=?,available_quantity=?,shelf_number=? WHERE book_id=?",
                    (isbn, data["title"], data["author"], data["category"], data["publisher"], year,
                     data["language"] or "English", qty, avail, data["shelf_number"], book_id))
            log(by, f"Updated book {book_id}")
        else:
            last = query("SELECT MAX(book_id) m FROM books")[0]["m"]
            new_id = f"B{(int(last[1:]) + 1 if last else 1):04d}"
            execute("INSERT INTO books VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                    (new_id, isbn, data["title"], data["author"], data["category"], data["publisher"], year,
                     data["language"] or "English", qty, qty, data["shelf_number"], today()))
            log(by, f"Added book {new_id} '{data['title']}'")
            add_notification(f"New book added: {data['title']}")
    except sqlite3.IntegrityError:
        raise LibraryError("A book with this ISBN already exists.")

def delete_book(book_id, by):
    if query("SELECT 1 FROM borrowings WHERE book_id=? AND status='ISSUED'", (book_id,)):
        raise LibraryError("Cannot delete: copies of this book are currently issued.")
    if query("SELECT 1 FROM borrowings WHERE book_id=?", (book_id,)):
        raise LibraryError("Cannot delete: this book has borrowing history.")
    execute("DELETE FROM books WHERE book_id=?", (book_id,))
    log(by, f"Deleted book {book_id}")

def issue_book(book_id, student_id, by):
    book = query("SELECT * FROM books WHERE book_id=?", (book_id.strip(),))
    if not book: raise LibraryError("Book not found.")
    stu = query("SELECT * FROM students WHERE student_id=?", (student_id.strip(),))
    if not stu: raise LibraryError("Student not found.")
    if stu[0]["status"] != "ACTIVE": raise LibraryError("This student account is blocked.")
    if book[0]["available_quantity"] < 1: raise LibraryError("Book is not available right now.")
    active = query("SELECT book_id FROM borrowings WHERE student_id=? AND status='ISSUED'", (student_id,))
    limit = get_setting("max_books", int)
    if len(active) >= limit: raise LibraryError(f"Borrowing limit reached ({limit} books).")
    if any(r["book_id"] == book_id for r in active): raise LibraryError("Student already has this book.")
    due = date.today() + timedelta(days=get_setting("loan_days", int))
    with closing(get_conn()) as conn, conn:
        conn.execute("INSERT INTO borrowings(book_id,student_id,issue_date,due_date,status,issued_by) "
                     "VALUES(?,?,?,?,?,?)", (book_id, student_id, today(), due.isoformat(), "ISSUED", by))
        conn.execute("UPDATE books SET available_quantity=available_quantity-1 WHERE book_id=?", (book_id,))
    log(by, f"Book issued: {book_id} to {student_id}")
    return f"'{book[0]['title']}' issued to {stu[0]['full_name']}. Due on {due.isoformat()}."

def return_book(transaction_id, by):
    rows = query("SELECT * FROM borrowings WHERE transaction_id=?", (transaction_id,))
    if not rows: raise LibraryError("Transaction not found.")
    t = rows[0]
    if t["status"] == "RETURNED": raise LibraryError("This book was already returned.")
    days, fine = calc_fine(t["due_date"])
    with closing(get_conn()) as conn, conn:
        conn.execute("UPDATE borrowings SET return_date=?,fine=?,status='RETURNED',returned_by=? WHERE transaction_id=?",
                     (today(), fine, by, transaction_id))
        conn.execute("UPDATE books SET available_quantity=available_quantity+1 WHERE book_id=?", (t["book_id"],))
        if fine > 0:
            conn.execute("INSERT INTO fines(transaction_id,overdue_days,fine_per_day,amount,status) VALUES(?,?,?,?,'PENDING')",
                         (transaction_id, days, get_setting("fine_per_day"), fine))
    log(by, f"Book returned: {t['book_id']} by {t['student_id']}" + (f" (fine {fine:.0f})" if fine else ""))
    add_notification(f"Book {t['book_id']} returned by {t['student_id']}")
    return f"Returned. Overdue days: {days}. Fine: {fine:.0f}."
