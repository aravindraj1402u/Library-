from database.database import query, execute
from services.fine_service import calc_fine
from utils.helpers import now, today

def add_notification(message, user_id=None):
    execute("INSERT INTO notifications(user_id,message,created_at) VALUES(?,?,?)", (user_id, message, now()))

def get_notifications(user):
    msgs = []
    if user["role"] == "STUDENT":
        for r in query("SELECT b.title, br.due_date FROM borrowings br JOIN books b USING(book_id) "
                       "WHERE br.student_id=? AND br.status='ISSUED'", (user["ref_id"],)):
            if r["due_date"] == today():
                msgs.append(f"DUE TODAY: '{r['title']}'")
            elif r["due_date"] < today():
                days, fine = calc_fine(r["due_date"])
                msgs.append(f"OVERDUE: '{r['title']}' ({days} days, fine {fine:.0f})")
    else:
        n = query("SELECT COUNT(*) c FROM borrowings WHERE status='ISSUED' AND due_date<?", (today(),))[0]["c"]
        d = query("SELECT COUNT(*) c FROM borrowings WHERE status='ISSUED' AND due_date=?", (today(),))[0]["c"]
        msgs += [f"{n} book(s) are overdue.", f"{d} book(s) are due today."]
    for r in query("SELECT message, created_at FROM notifications WHERE user_id IS NULL OR user_id=? "
                   "ORDER BY id DESC LIMIT 25", (user["user_id"],)):
        msgs.append(f"[{r['created_at']}] {r['message']}")
    return msgs
