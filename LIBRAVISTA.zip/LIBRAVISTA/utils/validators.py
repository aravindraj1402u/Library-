import re
from utils.helpers import LibraryError

def required(data, keys):
    for k in keys:
        if not str(data.get(k, "")).strip():
            raise LibraryError(f"'{k.replace('_', ' ').title()}' is required.")

def email(value):
    if not re.fullmatch(r"[\w.+-]+@[\w-]+\.[\w.-]+", value):
        raise LibraryError("Enter a valid email address.")

def phone(value):
    if not re.fullmatch(r"\d{10}", value):
        raise LibraryError("Phone number must be 10 digits.")

def student_id(value):
    if not re.fullmatch(r"[A-Za-z0-9]{4,15}", value):
        raise LibraryError("Student ID must be 4-15 letters/digits.")

def password(value):
    if len(value) < 8 or not re.search(r"[A-Za-z]", value) or not re.search(r"\d", value):
        raise LibraryError("Password needs 8+ characters with letters and digits.")

def positive_int(value, name="Value", minimum=0):
    try:
        n = int(value)
    except (TypeError, ValueError):
        raise LibraryError(f"{name} must be a whole number.")
    if n < minimum:
        raise LibraryError(f"{name} must be at least {minimum}.")
    return n

def isbn(value):
    d = value.replace("-", "").replace(" ", "")
    if len(d) == 13 and d.isdigit():
        total = sum(int(c) * (1 if i % 2 == 0 else 3) for i, c in enumerate(d[:12]))
        if (10 - total % 10) % 10 == int(d[12]):
            return d
    elif len(d) == 10 and re.fullmatch(r"\d{9}[\dXx]", d):
        total = sum((10 - i) * (10 if c in "Xx" else int(c)) for i, c in enumerate(d))
        if total % 11 == 0:
            return d
    raise LibraryError("Invalid ISBN (must be a valid ISBN-10 or ISBN-13).")
