from datetime import date, datetime

class LibraryError(Exception):
    """Friendly error shown to the user (never a traceback)."""

def today():
    return date.today().isoformat()

def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M")

def to_date(text):
    return datetime.strptime(text, "%Y-%m-%d").date()
