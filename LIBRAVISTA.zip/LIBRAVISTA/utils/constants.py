APP_NAME = "LIBRAVISTA"
TAGLINE = "Your Knowledge. Your Library. Your Future."
ROLES = ("ADMIN", "LIBRARIAN", "STUDENT")
NAVY, GOLD, BG, WHITE = "#12233f", "#e3a72f", "#f3f5f9", "#ffffff"
