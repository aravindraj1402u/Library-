"""Reusable Tkinter building blocks: buttons, tables, cards, charts, dialogs."""
import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox

from utils.constants import COLORS as C, FONT, STATUS_COLORS
from utils.helpers import AppError


# ---------- error handling ----------
def handle_error(exc, parent=None):
    """Show a friendly message instead of a Python traceback."""
    if isinstance(exc, AppError):
        messagebox.showerror("Please check", str(exc), parent=parent)
    elif isinstance(exc, sqlite3.IntegrityError):
        messagebox.showerror("Duplicate or invalid data", "That record conflicts with existing data.", parent=parent)
    elif isinstance(exc, sqlite3.Error):
        messagebox.showerror("Database error", "A database problem occurred. Please try again.", parent=parent)
    else:
        messagebox.showerror("Something went wrong", "An unexpected problem occurred. Please try again.", parent=parent)


def safe_call(func, *args, parent=None):
    """Run func; on failure show a friendly error.  Returns (success, result)."""
    try:
        return True, func(*args)
    except Exception as exc:  # GUI boundary: never let the app crash
        handle_error(exc, parent)
        return False, None


# ---------- styling ----------
def setup_style(root):
    style = ttk.Style(root)
    style.theme_use("clam")
    style.configure("Treeview", rowheight=27, font=(FONT, 10), background="white", fieldbackground="white", borderwidth=0)
    style.configure("Treeview.Heading", font=(FONT, 10, "bold"), background=C["sidebar"], foreground="white", relief="flat")
    style.map("Treeview.Heading", background=[("active", C["sidebar_hover"])])
    style.map("Treeview", background=[("selected", "#C7D2FE")], foreground=[("selected", C["text"])])
    style.configure("TNotebook", background=C["bg"], borderwidth=0)
    style.configure("TNotebook.Tab", font=(FONT, 10, "bold"), padding=(16, 7))


def make_button(parent, text, command, kind="primary"):
    colors = {"primary": (C["primary"], "white"), "danger": (C["red"], "white"),
              "success": (C["green"], "white"), "light": ("#E5E7EB", C["text"])}
    bg, fg = colors[kind]
    return tk.Button(parent, text=text, command=command, bg=bg, fg=fg, activebackground=bg, activeforeground=fg,
                     relief="flat", font=(FONT, 10, "bold"), padx=14, pady=6, cursor="hand2", bd=0)


def combo(parent, values, default, width=16, command=None):
    var = tk.StringVar(value=default)
    box = ttk.Combobox(parent, textvariable=var, values=values, state="readonly", width=width)
    if command:
        box.bind("<<ComboboxSelected>>", lambda e: command())
    return var, box


def draw_logo(canvas, x, y, size=60):
    """Simple open-book logo drawn with canvas shapes."""
    canvas.create_polygon(x, y + size * .25, x + size / 2, y + size * .4, x + size / 2, y + size,
                          x, y + size * .85, fill="#FFFFFF", outline="")
    canvas.create_polygon(x + size, y + size * .25, x + size / 2, y + size * .4, x + size / 2, y + size,
                          x + size, y + size * .85, fill="#A5B4FC", outline="")
    canvas.create_oval(x + size * .38, y - size * .05, x + size * .62, y + size * .19, fill=C["gold"], outline="")


# ---------- widgets ----------
class DataTable(tk.Frame):
    """A scrollable table. Rows whose 'tag column' holds a status name get a coloured badge look."""

    def __init__(self, parent, columns, height=10):
        super().__init__(parent, bg=C["card"], highlightbackground="#E5E7EB", highlightthickness=1)
        self.tree = ttk.Treeview(self, show="headings", height=height, selectmode="browse")
        scroll = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        for name, (bg, fg) in STATUS_COLORS.items():
            self.tree.tag_configure(name, background=bg, foreground=fg)
        self.set_columns(columns)

    def set_columns(self, columns):
        self.tree["columns"] = [c[0] for c in columns]
        for key, title, width in columns:
            self.tree.heading(key, text=title)
            self.tree.column(key, width=width, anchor="w", stretch=True)

    def set_rows(self, rows, tag_col=None):
        self.tree.delete(*self.tree.get_children())
        for row in rows:
            values = ["" if v is None else v for v in row]
            tag = str(values[tag_col]) if tag_col is not None else ""
            self.tree.insert("", "end", values=values, tags=(tag,))

    def selected(self):
        chosen = self.tree.selection()
        return self.tree.item(chosen[0])["values"] if chosen else None


class BasePage(tk.Frame):
    """Every screen inside the main window extends this (title + refresh())."""

    def __init__(self, parent, app, title, subtitle=""):
        super().__init__(parent, bg=C["bg"], padx=22, pady=16)
        self.app, self.user = app, app.user
        tk.Label(self, text=title, font=(FONT, 19, "bold"), bg=C["bg"], fg=C["text"]).pack(anchor="w")
        if subtitle:
            tk.Label(self, text=subtitle, font=(FONT, 10), bg=C["bg"], fg=C["muted"]).pack(anchor="w", pady=(0, 10))

    def refresh(self):
        pass

    def need_selection(self, table, message="Please select a row first."):
        row = table.selected()
        if not row:
            messagebox.showinfo("Select a row", message, parent=self)
        return row


def stat_grid(parent, items, per_row=4):
    """items = [(title, value, colour)] shown as dashboard cards."""
    for col in range(per_row):
        parent.columnconfigure(col, weight=1, uniform="cards")
    for i, (title, value, color) in enumerate(items):
        card = tk.Frame(parent, bg=C["card"], highlightbackground="#E5E7EB", highlightthickness=1)
        card.grid(row=i // per_row, column=i % per_row, sticky="ew", padx=5, pady=5)
        tk.Frame(card, bg=color, width=6).pack(side="left", fill="y")
        inner = tk.Frame(card, bg=C["card"])
        inner.pack(side="left", padx=14, pady=10)
        tk.Label(inner, text=str(value), font=(FONT, 20, "bold"), fg=color, bg=C["card"]).pack(anchor="w")
        tk.Label(inner, text=title, font=(FONT, 9), fg=C["muted"], bg=C["card"]).pack(anchor="w")


def bar_chart(parent, title, data, color, width=470, height=210):
    """Tiny bar chart drawn on a Canvas.  data = [(label, number), ...]"""
    canvas = tk.Canvas(parent, width=width, height=height, bg="white", highlightthickness=1,
                       highlightbackground="#E5E7EB")
    canvas.create_text(12, 10, text=title, anchor="nw", font=(FONT, 10, "bold"), fill=C["text"])
    top = max((v for _, v in data), default=0)
    if top <= 0:
        canvas.create_text(width // 2, height // 2, text="No data yet", fill=C["muted"], font=(FONT, 10))
        return canvas
    left, base = 18, height - 34
    slot = (width - 2 * left) / len(data)
    bar_w = min(48, slot * 0.6)
    for i, (label, value) in enumerate(data):
        x0 = left + i * slot + (slot - bar_w) / 2
        y0 = base - (base - 50) * value / top
        canvas.create_rectangle(x0, y0, x0 + bar_w, base, fill=color, outline="")
        canvas.create_text(x0 + bar_w / 2, y0 - 9, text=f"{value:g}", font=(FONT, 8), fill=C["text"])
        short = label if len(label) <= 10 else label[:9] + "…"
        canvas.create_text(x0 + bar_w / 2, base + 14, text=short, font=(FONT, 8), fill=C["muted"])
    canvas.create_line(left, base, width - left, base, fill="#9CA3AF")
    return canvas


class FormDialog(tk.Toplevel):
    """Generic pop-up form.
    fields = [(key, label, options)]  options: values=[...] (dropdown), strict=True, show='•', readonly=True
    on_save(data_dict) must raise AppError on problems; returning normally means success."""

    def __init__(self, parent, title, fields, on_save, initial=None, success=None, button="Save"):
        super().__init__(parent)
        self.title(title)
        self.configure(bg=C["card"])
        self.resizable(False, False)
        self.transient(parent.winfo_toplevel())
        self.on_save, self.success, self.vars = on_save, success, {}
        initial = initial or {}
        body = tk.Frame(self, bg=C["card"], padx=28, pady=20)
        body.pack()
        tk.Label(body, text=title, font=(FONT, 15, "bold"), bg=C["card"], fg=C["text"]).grid(
            row=0, column=0, columnspan=2, sticky="w", pady=(0, 12))
        first = None
        for i, (key, label, opts) in enumerate(fields, start=1):
            tk.Label(body, text=label, font=(FONT, 10), bg=C["card"], fg=C["muted"]).grid(
                row=i, column=0, sticky="w", pady=5, padx=(0, 16))
            var = tk.StringVar(value=str(initial.get(key, "") if initial.get(key) is not None else ""))
            if "values" in opts:
                widget = ttk.Combobox(body, textvariable=var, values=opts["values"], width=29,
                                      state="readonly" if opts.get("strict") else "normal")
            else:
                widget = tk.Entry(body, textvariable=var, width=32, show=opts.get("show", ""), font=(FONT, 10),
                                  state="readonly" if opts.get("readonly") else "normal")
            widget.grid(row=i, column=1, pady=5, ipady=2)
            self.vars[key] = var
            first = first or (None if opts.get("readonly") else widget)
        buttons = tk.Frame(body, bg=C["card"])
        buttons.grid(row=len(fields) + 1, column=0, columnspan=2, sticky="e", pady=(14, 0))
        make_button(buttons, "Cancel", self.destroy, "light").pack(side="left", padx=6)
        make_button(buttons, button, self.save).pack(side="left")
        self.bind("<Return>", lambda e: self.save())
        self.bind("<Escape>", lambda e: self.destroy())
        self.update_idletasks()
        x = parent.winfo_toplevel().winfo_rootx() + 120
        y = parent.winfo_toplevel().winfo_rooty() + 60
        self.geometry(f"+{x}+{y}")
        if first:
            first.focus_set()
        try:
            self.wait_visibility()
            self.grab_set()
        except tk.TclError:
            pass

    def save(self):
        data = {key: var.get().strip() for key, var in self.vars.items()}
        ok, _ = safe_call(self.on_save, data, parent=self)
        if ok:
            if self.success:
                messagebox.showinfo("Success", self.success, parent=self)
            self.destroy()
