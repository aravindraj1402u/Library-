"""Screens shared by all roles: Notifications and Profile."""
import tkinter as tk
from tkinter import messagebox

from auth.login import change_password
from database.database import query
from services.notification_service import generate_notifications, get_notifications
from utils.constants import COLORS as C, FONT
from utils.ui import BasePage, DataTable, FormDialog, make_button


class NotificationsPage(BasePage):
    def __init__(self, parent, app):
        super().__init__(parent, app, "🔔 Notifications", "Due dates, overdue books, fines and new arrivals")
        self.table = DataTable(self, [("d", "Date", 150), ("m", "Message", 800)], height=18)
        self.table.pack(fill="both", expand=True)
        self.refresh()

    def refresh(self):
        generate_notifications()
        self.table.set_rows([tuple(n) for n in get_notifications(self.user)])


class ProfilePage(BasePage):
    def __init__(self, parent, app):
        super().__init__(parent, app, "Profile", "Your account details")
        u = app.user
        details = [("Name", u["full_name"]), ("Username", u["username"]), ("Email", u["email"]), ("Role", u["role"])]
        if u.get("student_id"):
            s = query("SELECT * FROM students WHERE student_id = ?", (u["student_id"],), one=True)
            details += [("Student ID", s["student_id"]), ("Phone", s["phone"]), ("Department", s["department"]),
                        ("Year", s["year"]), ("Registered", s["registration_date"])]
        box = tk.Frame(self, bg=C["card"], padx=24, pady=18, highlightbackground="#E5E7EB", highlightthickness=1)
        box.pack(anchor="w")
        for i, (label, value) in enumerate(details):
            tk.Label(box, text=label, font=(FONT, 10), fg=C["muted"], bg=C["card"]).grid(row=i, column=0, sticky="w", pady=4, padx=(0, 30))
            tk.Label(box, text=str(value), font=(FONT, 11, "bold"), bg=C["card"]).grid(row=i, column=1, sticky="w")
        make_button(box, "Change Password", self.change).grid(row=len(details), column=0, columnspan=2, sticky="w", pady=(14, 0))

    def change(self):
        fields = [("old", "Current Password", {"show": "•"}), ("new", "New Password", {"show": "•"}),
                  ("confirm", "Confirm New Password", {"show": "•"})]
        FormDialog(self, "Change Password", fields, lambda d: change_password(self.user, d["old"], d["new"], d["confirm"]),
                   success="Password changed successfully.")
