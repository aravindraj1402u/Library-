"""LIBRAVISTA entry point. Run:  python main.py"""
from database.database import init_db
from ui.app import App

if __name__ == "__main__":
    init_db()          # creates library.db, tables and demo data on first run
    App().mainloop()
