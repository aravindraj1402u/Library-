"""Librarian management (admin only) - reuses the generic people screen."""
from admin.students import PeoplePage


class LibrariansPage(PeoplePage):
    def __init__(self, parent, app):
        super().__init__(parent, app, kind="librarian", can_manage=True)
