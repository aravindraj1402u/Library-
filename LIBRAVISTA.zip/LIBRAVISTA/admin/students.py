"""Student and librarian management screen (one class, two modes)."""
import tkinter as tk
from tkinter import messagebox, ttk

from auth.signup import (create_account, delete_person, get_person, list_people, person_key,
                         set_person_status, update_person)
from database.database import query
from services.fine_service import calculate_fine
from utils.constants import COLORS as C, CURRENCY, DEPARTMENTS, FONT
from utils.ui import BasePage, DataTable, FormDialog, make_button, safe_call

STUDENT_COLS = [("id", "ID", 70), ("name", "Name", 150), ("email", "Email", 200), ("phone", "Phone", 95),
                ("dept", "Department", 150), ("year", "Year", 45), ("user", "Username", 90), ("date", "Registered", 90),
                ("status", "Status", 80)]
LIBRARIAN_COLS = [("id", "ID", 70), ("name", "Name", 170), ("email", "Email", 240), ("phone", "Phone", 110),
                  ("user", "Username", 110), ("date", "Joined", 100), ("status", "Status", 80)]


def _form_fields(kind, editing):
    fields = []
    if kind == "student":
        fields.append(("student_id", "Student ID", {"readonly": editing}))
    fields += [("full_name", "Full Name", {}), ("email", "Email", {}), ("phone", "Phone", {})]
    if kind == "student":
        fields += [("department", "Department", {"values": DEPARTMENTS}),
                   ("year", "Year", {"values": ["1", "2", "3", "4", "5", "6"], "strict": True})]
    fields.append(("username", "Username", {"readonly": editing}))
    fields.append(("password", "New Password (blank = keep)" if editing else "Password", {"show": "•"}))
    return fields


class PeoplePage(BasePage):
    def __init__(self, parent, app, kind="student", can_manage=True):
        title = "Students" if kind == "student" else "Librarians"
        super().__init__(parent, app, title, f"Manage {title.lower()}" if can_manage else f"View {title.lower()}")
        self.kind, self.can_manage = kind, can_manage
        bar = tk.Frame(self, bg=C["bg"])
        bar.pack(fill="x", pady=(0, 8))
        self.term = tk.StringVar()
        tk.Entry(bar, textvariable=self.term, width=30, font=(FONT, 11), relief="solid", bd=1).pack(side="left", ipady=4)
        self.term.trace_add("write", lambda *_: self.refresh())
        if kind == "student":
            make_button(bar, "View Borrowings", self.view_borrowings, "light").pack(side="right", padx=3)
        if can_manage:
            make_button(bar, "Delete", self.delete, "danger").pack(side="right", padx=3)
            make_button(bar, "Activate / Deactivate", self.toggle, "light").pack(side="right", padx=3)
            make_button(bar, "Edit", self.edit, "light").pack(side="right", padx=3)
            make_button(bar, "＋ Add", self.add).pack(side="right", padx=3)
        cols = STUDENT_COLS if kind == "student" else LIBRARIAN_COLS
        self.table = DataTable(self, cols, height=16)
        self.table.pack(fill="both", expand=True)
        self.refresh()

    def refresh(self):
        rows = list_people(self.kind, self.term.get())
        self.table.set_rows(rows, tag_col=len(rows[0]) - 1 if rows else None)

    def _key(self):
        row = self.need_selection(self.table)
        return (person_key(self.kind, row[0]), row) if row else (None, None)

    def add(self):
        def save(data):
            create_account(self.kind, data, self.user["username"])
            self.refresh()
        FormDialog(self, f"Add {self.kind.title()}", _form_fields(self.kind, False), save)

    def edit(self):
        key, _ = self._key()
        if key is None:
            return
        ok, person = safe_call(get_person, self.kind, key, parent=self)
        if not ok:
            return
        def save(data):
            update_person(self.kind, key, data, self.user["username"])
            self.refresh()
        FormDialog(self, f"Edit {self.kind.title()}", _form_fields(self.kind, True), save, initial=person)

    def toggle(self):
        key, row = self._key()
        if key is None:
            return
        new_status = "INACTIVE" if row[-1] == "ACTIVE" else "ACTIVE"
        if messagebox.askyesno("Confirm", f"Set {row[1]} to {new_status}?", parent=self):
            ok, _ = safe_call(set_person_status, self.kind, key, new_status, self.user["username"], parent=self)
            if ok:
                self.refresh()

    def delete(self):
        key, row = self._key()
        if key is not None and messagebox.askyesno("Confirm delete", f"Delete {row[1]}? This cannot be undone.", parent=self):
            ok, _ = safe_call(delete_person, self.kind, key, self.user["username"], parent=self)
            if ok:
                self.refresh()

    def view_borrowings(self):
        key, row = self._key()
        if key is None:
            return
        win = tk.Toplevel(self)
        win.title(f"Borrowings - {row[1]}")
        win.geometry("760x340")
        table = DataTable(win, [("t", "Title", 260), ("i", "Issued", 90), ("d", "Due", 90), ("r", "Returned", 90),
                                ("f", "Fine", 60), ("s", "Status", 80)], height=12)
        table.pack(fill="both", expand=True, padx=10, pady=10)
        data = []
        for b in query("SELECT bk.title, b.issue_date, b.due_date, b.return_date, b.fine, b.status FROM borrowings b "
                       "JOIN books bk ON bk.book_id = b.book_id WHERE b.student_id = ? ORDER BY b.transaction_id DESC", (key,)):
            fine = calculate_fine(b["due_date"]) if b["status"] == "ISSUED" else b["fine"]
            data.append((b["title"], b["issue_date"], b["due_date"], b["return_date"], f"{CURRENCY}{fine:g}", b["status"]))
        table.set_rows(data, tag_col=5)
