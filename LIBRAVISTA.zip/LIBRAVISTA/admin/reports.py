"""Reports screen (with CSV / Excel export) and the Fines screen."""
import tkinter as tk
from tkinter import messagebox

from database.database import db, query, log_activity
from services import report_service
from services.fine_service import fine_totals
from services.notification_service import add_notification
from utils.constants import COLORS as C, CURRENCY, FONT, ROLE_ADMIN
from utils.helpers import ValidationError, require_role, today_str
from utils.ui import BasePage, DataTable, combo, make_button, safe_call, stat_grid


class ReportsPage(BasePage):
    def __init__(self, parent, app):
        super().__init__(parent, app, "Reports", "View a report on screen or export it to the exports/ folder")
        bar = tk.Frame(self, bg=C["bg"])
        bar.pack(fill="x", pady=(0, 8))
        self.name, box = combo(bar, list(report_service.REPORTS), "All books", 24, self.refresh)
        box.pack(side="left")
        make_button(bar, "Export Excel", lambda: self.export("xlsx"), "success").pack(side="right", padx=3)
        make_button(bar, "Export CSV", lambda: self.export("csv")).pack(side="right", padx=3)
        self.count = tk.Label(bar, bg=C["bg"], fg=C["muted"], font=(FONT, 10))
        self.count.pack(side="left", padx=12)
        self.table = DataTable(self, [("x", "", 100)], height=17)
        self.table.pack(fill="both", expand=True)
        self.refresh()

    def refresh(self):
        columns, rows = report_service.run_report(self.name.get())
        self.table.set_columns([(f"c{i}", name, 120 if i else 90) for i, name in enumerate(columns)])
        self.table.set_rows(rows)
        self.count.config(text=f"{len(rows)} record(s)")

    def export(self, fmt):
        ok, path = safe_call(report_service.export_report, self.name.get(), fmt, self.user["username"], parent=self)
        if ok:
            messagebox.showinfo("Export complete", f"Saved to:\n{path}", parent=self)


def mark_fine_paid(fine_id, user):
    require_role(user, ROLE_ADMIN)
    row = query("SELECT f.*, s.user_id, s.full_name FROM fines f JOIN borrowings b ON b.transaction_id=f.transaction_id "
                "JOIN students s ON s.student_id=b.student_id WHERE f.fine_id = ?", (fine_id,), one=True)
    if not row:
        raise ValidationError("Fine record not found.")
    if row["payment_status"] == "PAID":
        raise ValidationError("This fine is already paid.")
    with db() as conn:
        conn.execute("UPDATE fines SET payment_status='PAID', paid_at=? WHERE fine_id=?", (today_str(), fine_id))
    log_activity(user["username"], f"Fine paid: {CURRENCY}{row['amount']:g} by {row['full_name']}")
    add_notification(f"Payment received: your fine of {CURRENCY}{row['amount']:g} is marked PAID.", user_id=row["user_id"])


class FinesPage(BasePage):
    def __init__(self, parent, app):
        super().__init__(parent, app, "Fines", "Fine = overdue days × fine per day")
        self.cards = tk.Frame(self, bg=C["bg"])
        self.cards.pack(fill="x")
        bar = tk.Frame(self, bg=C["bg"])
        bar.pack(fill="x", pady=8)
        make_button(bar, "Mark Selected as PAID", self.pay, "success").pack(side="right")
        cols = [("id", "Fine ID", 60), ("tx", "Txn", 45), ("sid", "Student ID", 80), ("name", "Student", 140),
                ("title", "Book", 240), ("days", "Overdue Days", 90), ("rate", "Per Day", 65), ("amt", "Total Fine", 80),
                ("status", "Payment", 85)]
        self.table = DataTable(self, cols, height=14)
        self.table.pack(fill="both", expand=True)
        self.refresh()

    def refresh(self):
        for child in self.cards.winfo_children():
            child.destroy()
        t = fine_totals()
        stat_grid(self.cards, [("Collected (PAID)", f"{CURRENCY}{t['paid']:g}", C["green"]),
                               ("Pending", f"{CURRENCY}{t['pending']:g}", C["amber"]),
                               ("Accruing on overdue books", f"{CURRENCY}{t['accruing']:g}", C["red"])], per_row=3)
        rows = query("SELECT f.fine_id, f.transaction_id, s.student_id, s.full_name, bk.title, f.overdue_days, f.fine_per_day, "
                     "f.amount, f.payment_status FROM fines f JOIN borrowings b ON b.transaction_id=f.transaction_id "
                     "JOIN books bk ON bk.book_id=b.book_id JOIN students s ON s.student_id=b.student_id "
                     "ORDER BY f.fine_id DESC")
        self.table.set_rows([tuple(r) for r in rows], tag_col=8)

    def pay(self):
        row = self.need_selection(self.table, "Select a fine first.")
        if row and messagebox.askyesno("Confirm", f"Mark fine of {CURRENCY}{row[7]} as PAID?", parent=self):
            ok, _ = safe_call(mark_fine_paid, int(row[0]), self.user, parent=self)
            if ok:
                self.refresh()
