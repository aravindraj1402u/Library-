"""Book management: backend functions + the Books screen (used by admin, librarian and student)."""
import tkinter as tk
from datetime import date
from tkinter import messagebox

from database.database import db, query, log_activity
from services.notification_service import add_notification
from services.recommendation_service import recommend_books
from utils.constants import CATEGORIES, COLORS as C, FONT, ROLE_ADMIN, ROLE_LIBRARIAN
from utils.helpers import ValidationError, availability_status, now_str, require_role, today_str
from utils.ui import BasePage, DataTable, FormDialog, combo, make_button, safe_call
from utils.validators import validate_int, validate_isbn, validate_required

SEARCH_FIELDS = {"All fields": None, "Title": "title", "Author": "author", "ISBN": "isbn",
                 "Category": "category", "Publisher": "publisher", "Shelf": "shelf_number"}
BOOK_FORM = [("isbn", "ISBN", {}), ("title", "Title", {}), ("author", "Author", {}),
             ("category", "Category", {"values": CATEGORIES}), ("publisher", "Publisher", {}),
             ("publication_year", "Publication Year", {}), ("language", "Language", {}),
             ("quantity", "Quantity", {}), ("shelf_number", "Shelf Number", {})]


# ---------------- backend ----------------
def _clean(data):
    validate_required(data, {"isbn": "ISBN", "title": "Title", "author": "Author", "category": "Category",
                             "shelf_number": "Shelf number", "quantity": "Quantity"})
    return {"isbn": validate_isbn(data["isbn"]), "title": data["title"].strip(), "author": data["author"].strip(),
            "category": data["category"].strip(), "publisher": data.get("publisher", "").strip(),
            "year": validate_int(data.get("publication_year") or date.today().year, "Publication year", 1000, date.today().year + 1),
            "language": data.get("language", "").strip() or "English",
            "quantity": validate_int(data["quantity"], "Quantity", 0, 10000),
            "shelf": data["shelf_number"].strip()}


def next_book_id():
    row = query("SELECT MAX(CAST(SUBSTR(book_id, 2) AS INTEGER)) AS m FROM books", one=True)
    return f"B{(row['m'] or 0) + 1:04d}"


def add_book(data, user):
    require_role(user, ROLE_ADMIN, ROLE_LIBRARIAN)
    book = _clean(data)
    if query("SELECT 1 FROM books WHERE isbn = ?", (book["isbn"],), one=True):
        raise ValidationError("A book with this ISBN already exists.")
    book_id = next_book_id()
    with db() as conn:
        conn.execute("INSERT INTO books (book_id,isbn,title,author,category,publisher,publication_year,language,"
                     "quantity,available_quantity,shelf_number,added_date) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                     (book_id, book["isbn"], book["title"], book["author"], book["category"], book["publisher"],
                      book["year"], book["language"], book["quantity"], book["quantity"], book["shelf"], today_str()))
    log_activity(user["username"], f"Added book: {book['title']} ({book_id})")
    add_notification(f"New book added: '{book['title']}' by {book['author']}.")
    return book_id


def update_book(book_id, data, user):
    require_role(user, ROLE_ADMIN, ROLE_LIBRARIAN)
    book = _clean(data)
    old = query("SELECT * FROM books WHERE book_id = ?", (book_id,), one=True)
    if not old:
        raise ValidationError("Book not found.")
    if query("SELECT 1 FROM books WHERE isbn = ? AND book_id <> ?", (book["isbn"], book_id), one=True):
        raise ValidationError("Another book already uses this ISBN.")
    issued = old["quantity"] - old["available_quantity"]
    if book["quantity"] < issued:
        raise ValidationError(f"Quantity cannot be less than the {issued} copies currently issued.")
    with db() as conn:
        conn.execute("UPDATE books SET isbn=?, title=?, author=?, category=?, publisher=?, publication_year=?, "
                     "language=?, quantity=?, available_quantity=?, shelf_number=? WHERE book_id=?",
                     (book["isbn"], book["title"], book["author"], book["category"], book["publisher"], book["year"],
                      book["language"], book["quantity"], book["quantity"] - issued, book["shelf"], book_id))
    log_activity(user["username"], f"Edited book: {book['title']} ({book_id})")


def delete_book(book_id, user):
    require_role(user, ROLE_ADMIN)            # librarians can NOT delete books
    book = query("SELECT title FROM books WHERE book_id = ?", (book_id,), one=True)
    if not book:
        raise ValidationError("Book not found.")
    if query("SELECT 1 FROM borrowings WHERE book_id = ? AND status = 'ISSUED'", (book_id,), one=True):
        raise ValidationError("This book is currently issued and cannot be deleted.")
    with db() as conn:
        conn.execute("DELETE FROM books WHERE book_id = ?", (book_id,))
    log_activity(user["username"], f"Deleted book: {book['title']} ({book_id})")


def search_books(term="", by="All fields", availability="All", category="All", author="All"):
    where, params = [], []
    term = term.strip()
    if term:
        columns = [SEARCH_FIELDS[by]] if SEARCH_FIELDS.get(by) else [c for c in SEARCH_FIELDS.values() if c]
        where.append("(" + " OR ".join(f"{c} LIKE ?" for c in columns) + ")")   # column names come from our dict
        params += [f"%{term}%"] * len(columns)
    if availability == "Available":
        where.append("available_quantity > 0")
    elif availability == "Issued":
        where.append("quantity > available_quantity")
    if category != "All":
        where.append("category = ?")
        params.append(category)
    if author != "All":
        where.append("author = ?")
        params.append(author)
    sql = "SELECT * FROM books" + (" WHERE " + " AND ".join(where) if where else "") + " ORDER BY title"
    return query(sql, params)


# ---------------- screen ----------------
class BooksPage(BasePage):
    def __init__(self, parent, app, mode="admin"):
        super().__init__(parent, app, "Search Books" if mode == "student" else "Books",
                         "Search by title, author, ISBN, category, publisher or shelf")
        self.mode = mode
        bar = tk.Frame(self, bg=C["bg"])
        bar.pack(fill="x", pady=(0, 8))
        self.term = tk.StringVar()
        tk.Entry(bar, textvariable=self.term, width=26, font=(FONT, 11), relief="solid", bd=1).pack(side="left", ipady=4, padx=(0, 6))
        self.term.trace_add("write", lambda *_: self.refresh())
        self.by, box = combo(bar, list(SEARCH_FIELDS), "All fields", 11, self.refresh)
        box.pack(side="left", padx=3)
        self.avail, box = combo(bar, ["All", "Available", "Issued"], "All", 9, self.refresh)
        box.pack(side="left", padx=3)
        self.cat, self.cat_box = combo(bar, ["All"], "All", 18, self.refresh)
        self.cat_box.pack(side="left", padx=3)
        self.auth, self.auth_box = combo(bar, ["All"], "All", 20, self.refresh)
        self.auth_box.pack(side="left", padx=3)
        if mode in ("admin", "librarian"):
            make_button(bar, "＋ Add", self.add).pack(side="right", padx=3)
            make_button(bar, "Edit", self.edit, "light").pack(side="right", padx=3)
        if mode == "admin":
            make_button(bar, "Delete", self.delete, "danger").pack(side="right", padx=3)

        cols = [("id", "ID", 60), ("isbn", "ISBN", 115), ("title", "Title", 250), ("author", "Author", 140),
                ("cat", "Category", 130), ("pub", "Publisher", 100), ("year", "Year", 50), ("qty", "Qty", 40),
                ("avail", "Avail", 45), ("shelf", "Shelf", 60), ("status", "Status", 105)]
        self.table = DataTable(self, cols, height=13 if mode != "student" else 9)
        self.table.pack(fill="both", expand=True)
        if mode == "student":
            tk.Label(self, text="⭐ Recommended for You", font=(FONT, 13, "bold"), bg=C["bg"], fg=C["text"]).pack(anchor="w", pady=(10, 4))
            self.rec_table = DataTable(self, [("t", "Title", 300), ("a", "Author", 170), ("c", "Category", 150), ("r", "Why", 300)], height=5)
            self.rec_table.pack(fill="x")
        self.refresh()

    def refresh(self):
        self.cat_box["values"] = ["All"] + [r[0] for r in query("SELECT DISTINCT category FROM books ORDER BY 1")]
        self.auth_box["values"] = ["All"] + [r[0] for r in query("SELECT DISTINCT author FROM books ORDER BY 1")]
        books = search_books(self.term.get(), self.by.get(), self.avail.get(), self.cat.get(), self.auth.get())
        rows = [(b["book_id"], b["isbn"], b["title"], b["author"], b["category"], b["publisher"], b["publication_year"],
                 b["quantity"], b["available_quantity"], b["shelf_number"],
                 availability_status(b["quantity"], b["available_quantity"])) for b in books]
        self.table.set_rows(rows, tag_col=10)
        if self.mode == "student" and self.user.get("student_id"):
            recs = recommend_books(self.user["student_id"], self.term.get())
            self.rec_table.set_rows([(r["title"], r["author"], r["category"], r["reason"]) for r in recs])

    def _selected_id(self):
        row = self.need_selection(self.table, "Please select a book first.")
        return str(row[0]) if row else None

    def _open_form(self, title, initial, on_save):
        FormDialog(self, title, BOOK_FORM, on_save, initial=initial)

    def add(self):
        def save(data):
            add_book(data, self.user)
            self.refresh()
        self._open_form("Add Book", {"language": "English", "quantity": "1"}, save)

    def edit(self):
        book_id = self._selected_id()
        if not book_id:
            return
        book = query("SELECT * FROM books WHERE book_id = ?", (book_id,), one=True)
        def save(data):
            update_book(book_id, data, self.user)
            self.refresh()
        self._open_form(f"Edit Book {book_id}", dict(book), save)

    def delete(self):
        book_id = self._selected_id()
        if book_id and messagebox.askyesno("Confirm delete", f"Delete book {book_id} and its returned history?\nThis cannot be undone.", parent=self):
            ok, _ = safe_call(delete_book, book_id, self.user, parent=self)
            if ok:
                self.refresh()
