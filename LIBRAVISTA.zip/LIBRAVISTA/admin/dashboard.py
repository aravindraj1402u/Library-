"""Admin / librarian dashboard: statistic cards, charts and recent-activity lists."""
import tkinter as tk
from tkinter import ttk

from services import report_service as rs
from utils.constants import COLORS as C, CURRENCY, FONT
from utils.ui import BasePage, DataTable, bar_chart, stat_grid


class AdminDashboard(BasePage):
    def __init__(self, parent, app):
        super().__init__(parent, app, f"Welcome, {app.user['full_name']}", "Library overview")
        self.cards = tk.Frame(self, bg=C["bg"])
        self.cards.pack(fill="x")
        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill="both", expand=True, pady=10)
        self.charts = tk.Frame(self.tabs, bg=C["bg"], pady=8)
        self.lists = tk.Frame(self.tabs, bg=C["bg"], pady=8)
        self.tabs.add(self.charts, text="  Charts  ")
        self.tabs.add(self.lists, text="  Popular • Recent  ")
        self.refresh()

    def refresh(self):
        for frame in (self.cards, self.charts, self.lists):
            for child in frame.winfo_children():
                child.destroy()
        s = rs.dashboard_stats()
        stat_grid(self.cards, [
            ("Total Books", s["total_books"], C["primary"]), ("Available Books", s["available_books"], C["green"]),
            ("Issued Books", s["issued_books"], C["blue"]), ("Total Students", s["students"], C["purple"]),
            ("Total Librarians", s["librarians"], C["teal"]), ("Overdue Books", s["overdue"], C["red"]),
            ("Total Fines", f"{CURRENCY}{s['total_fines']:g}", C["amber"]), ("Added (30 days)", s["recent_books"], C["gold"])])
        charts = [("Books by category", rs.books_by_category(), C["primary"]),
                  ("Monthly borrowing", rs.monthly_borrowing(), C["teal"]),
                  ("Most borrowed books", rs.most_borrowed(), C["purple"]),
                  (f"Fine statistics ({CURRENCY})", rs.fine_statistics(), C["amber"])]
        for i, (title, data, color) in enumerate(charts):
            bar_chart(self.charts, title, data, color).grid(row=i // 2, column=i % 2, padx=8, pady=6)
        blocks = [("🔥 Popular Books", [("t", "Title", 210), ("n", "Times", 50)], rs.popular_books()),
                  ("🆕 Recently Added", [("t", "Title", 210), ("d", "Added", 80)], rs.recently_added()),
                  ("↩ Recently Returned", [("t", "Title", 170), ("s", "Student", 90), ("d", "Date", 80)], rs.recently_returned())]
        for i, (title, cols, rows) in enumerate(blocks):
            tk.Label(self.lists, text=title, font=(FONT, 12, "bold"), bg=C["bg"]).grid(row=0, column=i, sticky="w", padx=8)
            table = DataTable(self.lists, cols, height=8)
            table.grid(row=1, column=i, padx=8, sticky="n")
            table.set_rows(rows)
