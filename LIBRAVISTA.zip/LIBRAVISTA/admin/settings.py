"""Settings screen (max books, loan days, fine per day) and the Activity Logs screen."""
import tkinter as tk
from tkinter import messagebox

from database.database import query
from services.fine_service import get_setting, save_settings
from utils.constants import COLORS as C, CURRENCY, FONT
from utils.ui import BasePage, DataTable, make_button, safe_call


class SettingsPage(BasePage):
    def __init__(self, parent, app):
        super().__init__(parent, app, "Settings", "Library rules used when issuing books and calculating fines")
        box = tk.Frame(self, bg=C["card"], padx=24, pady=20, highlightbackground="#E5E7EB", highlightthickness=1)
        box.pack(anchor="w")
        self.vars = {}
        for row, (key, label) in enumerate([("max_books", "Maximum books per student"),
                                            ("loan_days", "Borrowing duration (days)"),
                                            ("fine_per_day", f"Fine per overdue day ({CURRENCY})")]):
            tk.Label(box, text=label, font=(FONT, 11), bg=C["card"]).grid(row=row, column=0, sticky="w", pady=8, padx=(0, 24))
            self.vars[key] = tk.StringVar(value=get_setting(key))
            tk.Entry(box, textvariable=self.vars[key], width=10, font=(FONT, 12), relief="solid", bd=1).grid(row=row, column=1, ipady=3)
        make_button(box, "Save Settings", self.save).grid(row=3, column=0, columnspan=2, sticky="e", pady=(16, 0))

    def save(self):
        ok, _ = safe_call(save_settings, self.vars["max_books"].get(), self.vars["loan_days"].get(),
                          self.vars["fine_per_day"].get(), self.user, parent=self)
        if ok:
            messagebox.showinfo("Saved", "Settings updated successfully.", parent=self)


class ActivityLogsPage(BasePage):
    def __init__(self, parent, app):
        super().__init__(parent, app, "Activity Logs", "Recent important actions in the system")
        self.term = tk.StringVar()
        tk.Entry(self, textvariable=self.term, width=30, font=(FONT, 11), relief="solid", bd=1).pack(anchor="w", ipady=4, pady=(0, 8))
        self.term.trace_add("write", lambda *_: self.refresh())
        self.table = DataTable(self, [("t", "Time", 150), ("u", "User", 120), ("a", "Action", 640)], height=18)
        self.table.pack(fill="both", expand=True)
        self.refresh()

    def refresh(self):
        like = f"%{self.term.get().strip()}%"
        rows = query("SELECT timestamp, username, action FROM activity_logs WHERE username LIKE ? OR action LIKE ? "
                     "ORDER BY log_id DESC LIMIT 500", (like, like))
        self.table.set_rows([tuple(r) for r in rows])
