"""Issue / return logic + screens (Issue-Return and Overdue)."""
import tkinter as tk
from tkinter import messagebox

from database.database import db, query, log_activity
from services.fine_service import calculate_fine, get_number, overdue_days
from services.notification_service import add_notification
from utils.constants import COLORS as C, CURRENCY, FONT, ROLE_ADMIN, ROLE_LIBRARIAN
from utils.helpers import BorrowError, add_days, now_str, require_role, today_str
from utils.ui import BasePage, DataTable, make_button, safe_call


# ---------------- backend ----------------
def issue_book(book_ref, student_id, user):
    """Issue a book (book_ref = Book ID or ISBN). Returns (title, due_date)."""
    require_role(user, ROLE_ADMIN, ROLE_LIBRARIAN)
    ref, sid = book_ref.strip(), student_id.strip().upper()
    if not ref or not sid:
        raise BorrowError("Enter both the Student ID and the Book ID / ISBN.")
    max_books, loan_days = int(get_number("max_books")), int(get_number("loan_days"))
    with db() as conn:
        student = conn.execute("SELECT * FROM students WHERE UPPER(student_id) = ?", (sid,)).fetchone()
        if not student:
            raise BorrowError("Student not found.")
        if student["status"] != "ACTIVE":
            raise BorrowError("This student's account is inactive.")
        book = conn.execute("SELECT * FROM books WHERE UPPER(book_id) = ? OR isbn = ?",
                            (ref.upper(), ref.replace("-", ""))).fetchone()
        if not book:
            raise BorrowError("Book not found.")
        if book["available_quantity"] <= 0:
            raise BorrowError(f"'{book['title']}' is not available right now.")
        open_rows = conn.execute("SELECT book_id FROM borrowings WHERE student_id = ? AND status = 'ISSUED'",
                                 (student["student_id"],)).fetchall()
        if len(open_rows) >= max_books:
            raise BorrowError(f"Borrowing limit reached: a student can borrow at most {max_books} books.")
        if any(r["book_id"] == book["book_id"] for r in open_rows):
            raise BorrowError("This student already has a copy of this book.")
        due = add_days(loan_days)
        conn.execute("INSERT INTO borrowings (book_id, student_id, issue_date, due_date, status, issued_by) "
                     "VALUES (?, ?, ?, ?, 'ISSUED', ?)",
                     (book["book_id"], student["student_id"], today_str(), due, user["username"]))
        conn.execute("UPDATE books SET available_quantity = available_quantity - 1 WHERE book_id = ?", (book["book_id"],))
    log_activity(user["username"], f"Book issued: '{book['title']}' to {student['student_id']}")
    add_notification(f"Book issued: '{book['title']}'. Please return it by {due}.", user_id=student["user_id"])
    return book["title"], due


def return_book(transaction_id, user):
    """Return a book. Returns (title, overdue_days, fine)."""
    require_role(user, ROLE_ADMIN, ROLE_LIBRARIAN)
    rate = get_number("fine_per_day")
    with db() as conn:
        tx = conn.execute("SELECT b.*, bk.title, s.user_id FROM borrowings b "
                          "JOIN books bk ON bk.book_id = b.book_id JOIN students s ON s.student_id = b.student_id "
                          "WHERE b.transaction_id = ?", (transaction_id,)).fetchone()
        if not tx:
            raise BorrowError("Transaction not found.")
        if tx["status"] == "RETURNED":
            raise BorrowError("This book has already been returned.")
        late = overdue_days(tx["due_date"], today_str())
        fine = late * rate
        conn.execute("UPDATE borrowings SET return_date = ?, fine = ?, status = 'RETURNED', returned_by = ? "
                     "WHERE transaction_id = ?", (today_str(), fine, user["username"], transaction_id))
        conn.execute("UPDATE books SET available_quantity = available_quantity + 1 WHERE book_id = ?", (tx["book_id"],))
        if fine > 0:
            conn.execute("INSERT INTO fines (transaction_id, overdue_days, fine_per_day, amount, payment_status, created_at) "
                         "VALUES (?, ?, ?, ?, 'PENDING', ?)", (transaction_id, late, rate, fine, now_str()))
    log_activity(user["username"], f"Book returned: '{tx['title']}' by {tx['student_id']}")
    add_notification(f"Book returned: '{tx['title']}' on {today_str()}. Thank you!", user_id=tx["user_id"])
    if fine > 0:
        log_activity(user["username"], f"Fine generated: {CURRENCY}{fine:g} for {tx['student_id']} ({late} days late)")
        add_notification(f"Fine pending: {CURRENCY}{fine:g} for '{tx['title']}' ({late} days late).", user_id=tx["user_id"])
    return tx["title"], late, fine


def open_borrowings(term=""):
    like = f"%{term.strip()}%"
    return query("SELECT b.transaction_id, b.book_id, bk.title, s.student_id, s.full_name, b.issue_date, b.due_date "
                 "FROM borrowings b JOIN books bk ON bk.book_id = b.book_id JOIN students s ON s.student_id = b.student_id "
                 "WHERE b.status = 'ISSUED' AND (bk.title LIKE ? OR s.full_name LIKE ? OR s.student_id LIKE ? "
                 "OR b.book_id LIKE ?) ORDER BY b.due_date", (like,) * 4)


def _rows(term=""):
    rows = []
    for r in open_borrowings(term):
        late = overdue_days(r["due_date"])
        rows.append((r["transaction_id"], r["book_id"], r["title"], r["student_id"], r["full_name"], r["issue_date"],
                     r["due_date"], late, f"{CURRENCY}{calculate_fine(r['due_date']):g}", "OVERDUE" if late else "ISSUED"))
    return rows


COLS = [("tx", "Txn", 45), ("bid", "Book ID", 65), ("title", "Title", 230), ("sid", "Student ID", 80),
        ("name", "Student", 130), ("iss", "Issued", 90), ("due", "Due", 90), ("late", "Days Late", 70),
        ("fine", "Fine", 60), ("status", "Status", 85)]


# ---------------- screens ----------------
class IssueReturnPage(BasePage):
    def __init__(self, parent, app):
        super().__init__(parent, app, "Issue / Return", "Issue books to students and record returns")
        box = tk.Frame(self, bg=C["card"], padx=16, pady=12, highlightbackground="#E5E7EB", highlightthickness=1)
        box.pack(fill="x", pady=(0, 10))
        self.student, self.book = tk.StringVar(), tk.StringVar()
        for label, var in (("Student ID", self.student), ("Book ID or ISBN", self.book)):
            tk.Label(box, text=label, bg=C["card"], font=(FONT, 10), fg=C["muted"]).pack(side="left", padx=(0, 6))
            tk.Entry(box, textvariable=var, width=18, font=(FONT, 11), relief="solid", bd=1).pack(side="left", ipady=3, padx=(0, 14))
        make_button(box, "Issue Book", self.issue, "success").pack(side="left")
        self.info = tk.Label(box, bg=C["card"], fg=C["muted"], font=(FONT, 9))
        self.info.pack(side="right")

        bar = tk.Frame(self, bg=C["bg"])
        bar.pack(fill="x", pady=(0, 6))
        tk.Label(bar, text="Currently issued books", font=(FONT, 13, "bold"), bg=C["bg"]).pack(side="left")
        make_button(bar, "Return Selected Book", self.give_back).pack(side="right")
        self.term = tk.StringVar()
        tk.Entry(bar, textvariable=self.term, width=22, font=(FONT, 10), relief="solid", bd=1).pack(side="right", ipady=3, padx=10)
        tk.Label(bar, text="Search:", bg=C["bg"]).pack(side="right")
        self.term.trace_add("write", lambda *_: self.refresh())
        self.table = DataTable(self, COLS, height=14)
        self.table.pack(fill="both", expand=True)
        self.refresh()

    def refresh(self):
        self.table.set_rows(_rows(self.term.get()), tag_col=9)
        self.info.config(text=f"Limit: {int(get_number('max_books'))} books • {int(get_number('loan_days'))} days • "
                              f"{CURRENCY}{get_number('fine_per_day'):g}/day late fine")

    def issue(self):
        ok, result = safe_call(issue_book, self.book.get(), self.student.get(), self.user, parent=self)
        if ok:
            messagebox.showinfo("Book issued", f"'{result[0]}' issued successfully.\nDue date: {result[1]}", parent=self)
            self.book.set("")
            self.refresh()

    def give_back(self):
        row = self.need_selection(self.table, "Select the book to return from the table.")
        if row and messagebox.askyesno("Confirm return", f"Return '{row[2]}' from {row[4]}?", parent=self):
            ok, result = safe_call(return_book, int(row[0]), self.user, parent=self)
            if ok:
                title, late, fine = result
                messagebox.showinfo("Book returned", f"'{title}' returned.\nOverdue days: {late}\n"
                                    f"Fine per day: {CURRENCY}{get_number('fine_per_day'):g}\nTotal fine: {CURRENCY}{fine:g}"
                                    + ("\nPayment status: PENDING" if fine else ""), parent=self)
                self.refresh()


class OverduePage(BasePage):
    def __init__(self, parent, app):
        super().__init__(parent, app, "Overdue Books", "Books not returned by their due date")
        self.table = DataTable(self, COLS, height=18)
        self.table.pack(fill="both", expand=True)
        self.refresh()

    def refresh(self):
        self.table.set_rows([r for r in _rows() if r[9] == "OVERDUE"], tag_col=9)
