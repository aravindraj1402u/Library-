"""Librarian dashboard = the same overview as the admin dashboard."""
from admin.dashboard import AdminDashboard


class LibrarianDashboard(AdminDashboard):
    pass
