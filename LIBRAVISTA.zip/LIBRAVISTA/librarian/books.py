"""Librarian book screen: search, add and edit (no delete)."""
from admin.books import BooksPage


class LibrarianBooksPage(BooksPage):
    def __init__(self, parent, app):
        super().__init__(parent, app, mode="librarian")
