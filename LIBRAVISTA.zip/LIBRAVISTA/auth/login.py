from database.database import query, execute, log
from auth.password import verify_password, hash_password
from utils import validators as v
from utils.helpers import LibraryError

def authenticate(identifier, password, role):
    v.required({"username_or_email": identifier, "password": password}, ["username_or_email", "password"])
    rows = query("SELECT * FROM users WHERE (username=? OR email=?) AND role=?", (identifier.strip(), identifier.strip(), role))
    if not rows or not verify_password(password, rows[0]["password_hash"]):
        raise LibraryError("Invalid username, password or role.")
    u = rows[0]
    if u["status"] != "ACTIVE": raise LibraryError("This account is blocked. Contact the library.")
    ref = None
    if role == "STUDENT":
        ref = query("SELECT student_id FROM students WHERE user_id=?", (u["user_id"],))[0]["student_id"]
    elif role == "LIBRARIAN":
        ref = query("SELECT librarian_id FROM librarians WHERE user_id=?", (u["user_id"],))[0]["librarian_id"]
    log(u["username"], f"{role} logged in")
    return {"user_id": u["user_id"], "username": u["username"], "role": role, "full_name": u["full_name"], "ref_id": ref}

def reset_password(username, email, new_password):
    v.password(new_password)
    rows = query("SELECT user_id FROM users WHERE username=? AND email=?", (username, email))
    if not rows: raise LibraryError("No account matches that username and email.")
    execute("UPDATE users SET password_hash=? WHERE user_id=?", (hash_password(new_password), rows[0]["user_id"]))
    log(username, "Password reset")
