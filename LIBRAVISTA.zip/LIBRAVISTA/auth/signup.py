import sqlite3
from contextlib import closing
from database.database import get_conn, query, log
from auth.password import hash_password
from utils import validators as v
from utils.helpers import LibraryError, today

def _check_unique(data):
    if query("SELECT 1 FROM students WHERE student_id=?", (data["student_id"],)): raise LibraryError("Student ID already registered.")
    if query("SELECT 1 FROM users WHERE email=?", (data["email"],)): raise LibraryError("Email already registered.")
    if query("SELECT 1 FROM users WHERE username=?", (data["username"],)): raise LibraryError("Username already taken.")

def register_student(d):
    v.required(d, ["full_name", "student_id", "email", "phone", "department", "year", "username", "password", "confirm"])
    v.student_id(d["student_id"]); v.email(d["email"]); v.phone(d["phone"]); v.password(d["password"])
    v.positive_int(d["year"], "Year", 1)
    if d["password"] != d["confirm"]: raise LibraryError("Passwords do not match.")
    _check_unique(d)
    try:
        with closing(get_conn()) as conn, conn:
            uid = conn.execute("INSERT INTO users(username,email,password_hash,role,full_name) VALUES(?,?,?,?,?)",
                (d["username"], d["email"], hash_password(d["password"]), "STUDENT", d["full_name"])).lastrowid
            conn.execute("INSERT INTO students VALUES(?,?,?,?,?,?,?,?,?)", (d["student_id"], uid, d["full_name"],
                d["email"], d["phone"], d["department"], d["year"], today(), "ACTIVE"))
    except sqlite3.IntegrityError:
        raise LibraryError("Duplicate record found.")
    log(d["username"], "Student registered")

def register_librarian(d, by):
    v.required(d, ["full_name", "email", "phone", "username", "password"])
    v.email(d["email"]); v.phone(d["phone"]); v.password(d["password"])
    if query("SELECT 1 FROM users WHERE email=? OR username=?", (d["email"], d["username"])):
        raise LibraryError("Email or username already exists.")
    with closing(get_conn()) as conn, conn:
        uid = conn.execute("INSERT INTO users(username,email,password_hash,role,full_name) VALUES(?,?,?,?,?)",
            (d["username"], d["email"], hash_password(d["password"]), "LIBRARIAN", d["full_name"])).lastrowid
        conn.execute("INSERT INTO librarians(user_id,full_name,email,phone,joining_date) VALUES(?,?,?,?,?)",
            (uid, d["full_name"], d["email"], d["phone"], today()))
    log(by, f"Librarian added: {d['username']}")
