import os, tempfile, unittest
from datetime import date, timedelta
from database import database

database.DB_PATH = os.path.join(tempfile.mkdtemp(), "test.db")
from auth import login, signup
from services import circulation_service as circ, fine_service as fines, recommendation_service as rec, report_service
from utils.helpers import LibraryError

class LibraryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): database.init_db()

    def test_login_ok_and_wrong_password(self):
        self.assertEqual(login.authenticate("admin", "Admin@123", "ADMIN")["role"], "ADMIN")
        with self.assertRaises(LibraryError): login.authenticate("admin", "bad", "ADMIN")
        with self.assertRaises(LibraryError): login.authenticate("admin", "Admin@123", "STUDENT")

    def test_signup_and_duplicate(self):
        d = dict(full_name="T", student_id="T9001", email="t@x.com", phone="9999999999", department="CS",
                 year="1", username="t9001", password="Passw0rd1", confirm="Passw0rd1")
        signup.register_student(d)
        with self.assertRaises(LibraryError): signup.register_student(d)

    def test_book_crud_and_search(self):
        data = dict(isbn="9780306406157", title="Test Book", author="A", category="C", publisher="P",
                    publication_year="2020", language="", quantity="2", shelf_number="X1")
        circ.save_book(data, "admin")
        self.assertTrue(database.query("SELECT 1 FROM books WHERE title LIKE '%Test Book%'"))
        with self.assertRaises(LibraryError): circ.save_book(dict(data, isbn="123"), "admin")
        bid = database.query("SELECT book_id FROM books WHERE isbn='9780306406157'")[0][0]
        circ.save_book(dict(data, title="Renamed"), "admin", bid); circ.delete_book(bid, "admin")

    def test_issue_return_fine_limit(self):
        with self.assertRaises(LibraryError): circ.issue_book("B0016", "NOPE", "lib1")
        circ.issue_book("B0016", "S1004", "lib1")
        circ.issue_book("B0013", "S1004", "lib1")
        with self.assertRaises(LibraryError): circ.issue_book("B0012", "S1004", "lib1")  # limit 3 (already has 1)
        tid = database.query("SELECT transaction_id FROM borrowings WHERE book_id='B0016' AND student_id='S1004' AND status='ISSUED'")[0][0]
        database.execute("UPDATE borrowings SET due_date=? WHERE transaction_id=?", ((date.today() - timedelta(days=5)).isoformat(), tid))
        self.assertIn("Fine: 25", circ.return_book(tid, "lib1"))
        with self.assertRaises(LibraryError): circ.return_book(tid, "lib1")

    def test_fine_calc_and_recommend_and_export(self):
        self.assertEqual(fines.calc_fine((date.today() - timedelta(days=3)).isoformat()), (3, 15.0))
        self.assertTrue(rec.recommend("S1001"))
        self.assertTrue(os.path.exists(report_service.export("All Books", "csv")))

if __name__ == "__main__":
    unittest.main()
