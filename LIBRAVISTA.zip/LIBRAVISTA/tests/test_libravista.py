"""Run with:  python -m unittest discover -s tests -v   (from the LIBRAVISTA folder)"""
import os
import sys
import tempfile
import unittest
from datetime import date, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import database.database as dbm
import services.report_service as rs
from admin.books import add_book, delete_book, search_books, update_book
from admin.reports import mark_fine_paid
from auth.login import authenticate, logout, reset_password
from auth.password import hash_password, verify_password
from auth.signup import create_account
from database.database import init_database, query
from database.seed import seed_admin, seed_demo, seed_settings, DEMO_PASSWORD
from librarian.issue_return import issue_book, return_book
from services.fine_service import calculate_fine, overdue_days, save_settings
from services.recommendation_service import recommend_books
from utils.helpers import (AppError, AuthError, BorrowError, PermissionDenied, ValidationError, availability_status)
from utils.validators import make_isbn13, validate_isbn

ADMIN = {"user_id": 1, "username": "admin", "role": "ADMIN"}
LIBRARIAN = {"user_id": 2, "username": "librarian1", "role": "LIBRARIAN"}
STUDENT = {"user_id": 3, "username": "aarav", "role": "STUDENT"}


def book_data(isbn="9780262033848", **extra):
    data = {"isbn": isbn, "title": "Test Book", "author": "Some Author", "category": "Database", "publisher": "Pub",
            "publication_year": "2020", "language": "English", "quantity": "2", "shelf_number": "ZZ-99"}
    data.update(extra)
    return data


class LibraryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        dbm.DB_PATH = Path(self.tmp.name) / "test.db"
        rs.EXPORT_DIR = Path(self.tmp.name) / "exports"
        init_database()
        seed_settings()
        seed_admin(password="Admin@1234", write_file=False)
        seed_demo()

    def tearDown(self):
        self.tmp.cleanup()

    # ---- login / signup ----
    def test_login_ok_and_wrong_password(self):
        self.assertEqual(authenticate("admin", "Admin@1234", "ADMIN")["role"], "ADMIN")
        with self.assertRaises(AuthError):
            authenticate("admin", "wrong", "ADMIN")
        with self.assertRaises(AuthError):
            authenticate("admin", "Admin@1234", "STUDENT")          # wrong role
        self.assertEqual(authenticate("aarav", DEMO_PASSWORD, "STUDENT")["student_id"], "S1001")

    def test_password_is_hashed(self):
        stored = query("SELECT password_hash FROM users WHERE username='admin'", one=True)[0]
        self.assertNotIn("Admin@1234", stored)
        self.assertTrue(verify_password("x1y2z3w4", hash_password("x1y2z3w4")))

    def test_signup_and_duplicates(self):
        data = {"full_name": "New Student", "student_id": "S2001", "email": "new@x.com", "phone": "9999999999",
                "department": "Civil", "year": "2", "username": "newstu", "password": "Passw0rd1", "confirm_password": "Passw0rd1"}
        create_account("student", data)
        self.assertEqual(authenticate("newstu", "Passw0rd1", "STUDENT")["full_name"], "New Student")
        for field, value in (("student_id", "s2001"), ("email", "NEW@x.com"), ("username", "NEWSTU")):
            bad = dict(data, **{field: value})
            if field != "student_id":
                bad["student_id"] = "S2002"
            if field != "email":
                bad["email"] = "other@x.com"
            if field != "username":
                bad["username"] = "other"
            with self.assertRaises(ValidationError):
                create_account("student", bad)
        with self.assertRaises(ValidationError):
            create_account("student", dict(data, student_id="S3", email="a@b.com", username="u3", phone="123"))
        with self.assertRaises(ValidationError):
            create_account("student", dict(data, student_id="S4444", email="c@b.com", username="u4", confirm_password="nope"))

    def test_forgot_password(self):
        reset_password("aarav", "aarav@student.libravista.local", "NewPass123", "NewPass123")
        self.assertEqual(authenticate("aarav", "NewPass123", "STUDENT")["username"], "aarav")
        with self.assertRaises(AuthError):
            reset_password("aarav", "wrong@x.com", "NewPass123", "NewPass123")

    def test_logout_logged(self):
        logout(STUDENT)
        self.assertTrue(query("SELECT 1 FROM activity_logs WHERE action='Logged out'", one=True))

    # ---- books ----
    def test_book_crud_and_search(self):
        book_id = add_book(book_data(), LIBRARIAN)
        self.assertEqual(len(search_books("Test Book")), 1)
        self.assertEqual(len(search_books("ZZ-99", "Shelf")), 1)
        update_book(book_id, book_data(title="Renamed", quantity="5"), LIBRARIAN)
        self.assertEqual(search_books("Renamed")[0]["available_quantity"], 5)
        with self.assertRaises(ValidationError):
            add_book(book_data(), ADMIN)                           # duplicate ISBN
        with self.assertRaises(ValidationError):
            add_book(book_data(isbn="1234567890123"), ADMIN)       # bad checksum
        delete_book(book_id, ADMIN)
        self.assertEqual(len(search_books("Renamed")), 0)

    def test_search_filters(self):
        self.assertTrue(all(b["category"] == "Database" for b in search_books(category="Database")))
        self.assertTrue(all(b["available_quantity"] > 0 for b in search_books(availability="Available")))

    def test_isbn_validation(self):
        self.assertEqual(validate_isbn("978-0-262-03384-8"), "9780262033848")
        self.assertEqual(validate_isbn("0306406152"), "0306406152")
        with self.assertRaises(ValidationError):
            validate_isbn("12345")

    def test_role_permissions(self):
        book_id = add_book(book_data(), ADMIN)
        with self.assertRaises(PermissionDenied):
            delete_book(book_id, LIBRARIAN)
        with self.assertRaises(PermissionDenied):
            add_book(book_data(isbn=make_isbn13("978111111111")), STUDENT)
        with self.assertRaises(PermissionDenied):
            issue_book("B0001", "S1005", STUDENT)
        with self.assertRaises(PermissionDenied):
            save_settings(3, 14, 2, LIBRARIAN)

    # ---- issue / return / fines ----
    def test_issue_and_return(self):
        before = query("SELECT available_quantity a FROM books WHERE book_id='B0009'", one=True)["a"]
        title, due = issue_book("B0009", "s1005", LIBRARIAN)
        self.assertEqual(due, (date.today() + timedelta(days=14)).strftime("%Y-%m-%d"))
        after = query("SELECT available_quantity a FROM books WHERE book_id='B0009'", one=True)["a"]
        self.assertEqual(after, before - 1)
        tx = query("SELECT transaction_id t FROM borrowings WHERE student_id='S1005' AND book_id='B0009'", one=True)["t"]
        _, late, fine = return_book(tx, LIBRARIAN)
        self.assertEqual((late, fine), (0, 0))
        with self.assertRaises(BorrowError):
            return_book(tx, LIBRARIAN)                              # already returned
        with self.assertRaises(BorrowError):
            issue_book("B0009", "S9999", LIBRARIAN)                 # student not found
        with self.assertRaises(BorrowError):
            issue_book("B9999", "S1005", LIBRARIAN)                 # book not found

    def test_borrowing_limit(self):
        # S1004 already holds 2 books; limit is 3
        issue_book("B0001", "S1004", LIBRARIAN)
        with self.assertRaises(BorrowError):
            issue_book("B0002", "S1004", LIBRARIAN)
        save_settings(4, 14, 2, ADMIN)
        issue_book("B0002", "S1004", LIBRARIAN)

    def test_out_of_stock_book(self):
        issue_book("B0014", "S1001", LIBRARIAN)                     # only 1 copy
        with self.assertRaises(BorrowError):
            issue_book("B0014", "S1002", LIBRARIAN)

    def test_overdue_fine_calculation(self):
        self.assertEqual(overdue_days("2026-09-10", "2026-09-15"), 5)
        self.assertEqual(calculate_fine("2026-09-10", "2026-09-15"), 10)   # 5 days x 2
        self.assertEqual(calculate_fine("2026-09-10", "2026-09-05"), 0)
        save_settings(3, 14, 5, ADMIN)
        self.assertEqual(calculate_fine("2026-09-10", "2026-09-15"), 25)

    def test_return_overdue_generates_fine_and_payment(self):
        tx = query("SELECT transaction_id t FROM borrowings WHERE student_id='S1001' AND book_id='B0005' AND status='ISSUED'",
                   one=True)["t"]                                   # demo: overdue by 6 days
        _, late, fine = return_book(tx, ADMIN)
        self.assertEqual((late, fine), (6, 12))
        fine_row = query("SELECT * FROM fines WHERE transaction_id=?", (tx,), one=True)
        self.assertEqual(fine_row["payment_status"], "PENDING")
        mark_fine_paid(fine_row["fine_id"], ADMIN)
        self.assertEqual(query("SELECT payment_status p FROM fines WHERE fine_id=?", (fine_row["fine_id"],), one=True)["p"], "PAID")

    # ---- misc ----
    def test_recommendations_and_status(self):
        recs = recommend_books("S1001")
        self.assertTrue(recs)
        borrowed = {r["book_id"] for r in query("SELECT book_id FROM borrowings WHERE student_id='S1001'")}
        self.assertFalse(borrowed & {r["book_id"] for r in recs})
        self.assertEqual(availability_status(3, 3), "AVAILABLE")
        self.assertEqual(availability_status(3, 1), "LOW STOCK")
        self.assertEqual(availability_status(3, 0), "ISSUED")
        self.assertEqual(availability_status(0, 0), "OUT OF STOCK")

    def test_reports_and_export(self):
        for name in rs.REPORTS:
            columns, rows = rs.run_report(name)
            self.assertTrue(columns)
        csv_path = rs.export_report("All books", "csv", "admin")
        xlsx_path = rs.export_report("Popular books", "xlsx", "admin")
        self.assertTrue(csv_path.exists() and xlsx_path.exists())
        stats = rs.dashboard_stats()
        self.assertGreater(stats["total_books"], 0)
        self.assertEqual(len(rs.monthly_borrowing()), 6)


if __name__ == "__main__":
    unittest.main()
