SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  user_id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL, email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL, role TEXT NOT NULL, full_name TEXT NOT NULL,
  status TEXT DEFAULT 'ACTIVE');
CREATE TABLE IF NOT EXISTS students(
  student_id TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(user_id),
  full_name TEXT, email TEXT, phone TEXT, department TEXT, year TEXT,
  registration_date TEXT, status TEXT DEFAULT 'ACTIVE');
CREATE TABLE IF NOT EXISTS librarians(
  librarian_id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(user_id),
  full_name TEXT, email TEXT, phone TEXT, joining_date TEXT, status TEXT DEFAULT 'ACTIVE');
CREATE TABLE IF NOT EXISTS books(
  book_id TEXT PRIMARY KEY, isbn TEXT UNIQUE NOT NULL, title TEXT NOT NULL, author TEXT NOT NULL,
  category TEXT NOT NULL, publisher TEXT, publication_year INTEGER, language TEXT DEFAULT 'English',
  quantity INTEGER NOT NULL, available_quantity INTEGER NOT NULL, shelf_number TEXT, added_date TEXT);
CREATE TABLE IF NOT EXISTS borrowings(
  transaction_id INTEGER PRIMARY KEY AUTOINCREMENT,
  book_id TEXT NOT NULL REFERENCES books(book_id), student_id TEXT NOT NULL REFERENCES students(student_id),
  issue_date TEXT, due_date TEXT, return_date TEXT, fine REAL DEFAULT 0,
  status TEXT DEFAULT 'ISSUED', issued_by TEXT, returned_by TEXT);
CREATE TABLE IF NOT EXISTS fines(
  fine_id INTEGER PRIMARY KEY AUTOINCREMENT, transaction_id INTEGER NOT NULL REFERENCES borrowings(transaction_id),
  overdue_days INTEGER, fine_per_day REAL, amount REAL, status TEXT DEFAULT 'PENDING');
CREATE TABLE IF NOT EXISTS notifications(
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, message TEXT, created_at TEXT);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS activity_logs(
  id INTEGER PRIMARY KEY AUTOINCREMENT, user TEXT, action TEXT, timestamp TEXT);
"""
