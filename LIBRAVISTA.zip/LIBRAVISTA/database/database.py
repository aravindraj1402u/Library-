import os, sqlite3
from contextlib import closing
from database.schema import SCHEMA
from utils.helpers import now

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "library.db")

def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def query(sql, params=()):
    with closing(get_conn()) as conn:
        return conn.execute(sql, params).fetchall()

def execute(sql, params=()):
    with closing(get_conn()) as conn, conn:
        return conn.execute(sql, params).lastrowid

def log(user, action):
    execute("INSERT INTO activity_logs(user, action, timestamp) VALUES(?,?,?)", (user, action, now()))

def init_db():
    first_run = not os.path.exists(DB_PATH)
    with closing(get_conn()) as conn:
        conn.executescript(SCHEMA)
    if first_run:
        from database.seed import seed
        seed()
