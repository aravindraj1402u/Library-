from datetime import date, timedelta
from auth.password import hash_password
from database.database import execute, query, log

def _isbn13(n):
    prefix = "978" + str(n).zfill(9)
    total = sum(int(c) * (1 if i % 2 == 0 else 3) for i, c in enumerate(prefix))
    return prefix + str((10 - total % 10) % 10)

def add_user(username, email, password, role, name):
    return execute("INSERT INTO users(username,email,password_hash,role,full_name) VALUES(?,?,?,?,?)",
                   (username, email, hash_password(password), role, name))

def seed():
    for k, v in (("max_books", "3"), ("loan_days", "14"), ("fine_per_day", "5")):
        execute("INSERT OR REPLACE INTO settings VALUES(?,?)", (k, v))
    add_user("admin", "admin@libravista.edu", "Admin@123", "ADMIN", "System Administrator")
    for i, name in enumerate(["Meera Nair", "Rahul Menon"], 1):
        uid = add_user(f"lib{i}", f"lib{i}@libravista.edu", "Lib@12345", "LIBRARIAN", name)
        execute("INSERT INTO librarians(user_id,full_name,email,phone,joining_date) VALUES(?,?,?,?,?)",
                (uid, name, f"lib{i}@libravista.edu", f"98000000{i}0", "2024-06-01"))
    students = [("S1001", "Aarav Sharma", "Computer Science", "3"), ("S1002", "Diya Patel", "Computer Science", "2"),
                ("S1003", "Kabir Singh", "Electronics", "4"), ("S1004", "Isha Verma", "Mathematics", "1"),
                ("S1005", "Rohan Das", "Information Technology", "3")]
    for i, (sid, name, dept, yr) in enumerate(students, 1):
        uid = add_user(f"stu{i}", f"stu{i}@college.edu", "Student@123", "STUDENT", name)
        execute("INSERT INTO students VALUES(?,?,?,?,?,?,?,?,?)",
                (sid, uid, name, f"stu{i}@college.edu", f"90000000{i}0", dept, yr, "2025-07-01", "ACTIVE"))
    books = [("Introduction to Algorithms", "Thomas Cormen", "Computer Science", "MIT Press", 2009),
             ("Clean Code", "Robert Martin", "Computer Science", "Prentice Hall", 2008),
             ("Python Crash Course", "Eric Matthes", "Computer Science", "No Starch", 2019),
             ("Artificial Intelligence: A Modern Approach", "Stuart Russell", "Artificial Intelligence", "Pearson", 2020),
             ("Deep Learning", "Ian Goodfellow", "Artificial Intelligence", "MIT Press", 2016),
             ("Hands-On Machine Learning", "Aurelien Geron", "Artificial Intelligence", "O'Reilly", 2022),
             ("Database System Concepts", "Abraham Silberschatz", "Database", "McGraw Hill", 2019),
             ("Fundamentals of Database Systems", "Ramez Elmasri", "Database", "Pearson", 2016),
             ("SQL in 10 Minutes", "Ben Forta", "Database", "Sams", 2020),
             ("Computer Networking", "James Kurose", "Networking", "Pearson", 2021),
             ("TCP/IP Illustrated", "Richard Stevens", "Networking", "Addison-Wesley", 2011),
             ("Pride and Prejudice", "Jane Austen", "Literature", "Penguin", 2003),
             ("1984", "George Orwell", "Literature", "Penguin", 2008),
             ("Linear Algebra Done Right", "Sheldon Axler", "Mathematics", "Springer", 2015),
             ("Discrete Mathematics", "Kenneth Rosen", "Mathematics", "McGraw Hill", 2018),
             ("Microelectronic Circuits", "Adel Sedra", "Electronics", "Oxford", 2014)]
    for i, (t, a, c, p, y) in enumerate(books, 1):
        added = (date.today() - timedelta(days=i * 3)).isoformat()
        execute("INSERT INTO books VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                (f"B{i:04d}", _isbn13(100000 + i), t, a, c, p, y, "English", 3, 3, f"{c[:2].upper()}-{i:02d}", added))
    # (book, student, issued days ago, returned days ago or None)
    history = [("B0001", "S1001", 30, 20), ("B0003", "S1001", 10, None), ("B0004", "S1001", 25, None),
               ("B0003", "S1002", 40, 30), ("B0004", "S1002", 8, None), ("B0007", "S1002", 20, 12),
               ("B0001", "S1003", 5, None), ("B0010", "S1003", 35, 18), ("B0016", "S1003", 12, None),
               ("B0014", "S1004", 22, 10), ("B0015", "S1004", 3, None), ("B0003", "S1005", 15, 2)]
    for book, sid, ago, ret in history:
        issue = date.today() - timedelta(days=ago); due = issue + timedelta(days=14)
        ret_d = date.today() - timedelta(days=ret) if ret is not None else None
        fine = max(0, ((ret_d or date.today()) - due).days) * 5 if ret_d else 0
        tid = execute("INSERT INTO borrowings(book_id,student_id,issue_date,due_date,return_date,fine,status,issued_by) "
                      "VALUES(?,?,?,?,?,?,?,?)", (book, sid, issue.isoformat(), due.isoformat(),
                      ret_d.isoformat() if ret_d else None, fine, "RETURNED" if ret_d else "ISSUED", "lib1"))
        if fine:
            execute("INSERT INTO fines(transaction_id,overdue_days,fine_per_day,amount,status) VALUES(?,?,?,?,?)",
                    (tid, fine // 5, 5, fine, "PAID"))
    execute("UPDATE books SET available_quantity = quantity - (SELECT COUNT(*) FROM borrowings "
            "WHERE borrowings.book_id = books.book_id AND status='ISSUED')")
    log("system", "Database initialised with demo data")
