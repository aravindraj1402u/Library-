"""'My Books' screen + data helpers for a student's borrowed books."""
import tkinter as tk

from database.database import query
from services.fine_service import calculate_fine, overdue_days, pending_fine
from utils.constants import COLORS as C, CURRENCY, FONT
from utils.helpers import parse_date, today
from utils.ui import BasePage, DataTable

CURRENT_COLS = [("t", "Title", 260), ("a", "Author", 150), ("i", "Issued", 90), ("d", "Due Date", 90),
                ("l", "Days Left", 70), ("o", "Overdue Days", 90), ("f", "Fine", 70), ("s", "Status", 85)]


def current_books(student_id):
    """Rows for books the student still holds (includes overdue days and running fine)."""
    rows = []
    for b in query("SELECT bk.title, bk.author, b.issue_date, b.due_date FROM borrowings b "
                   "JOIN books bk ON bk.book_id = b.book_id WHERE b.student_id = ? AND b.status = 'ISSUED' "
                   "ORDER BY b.due_date", (student_id,)):
        late = overdue_days(b["due_date"])
        left = (parse_date(b["due_date"]) - today()).days
        rows.append((b["title"], b["author"], b["issue_date"], b["due_date"], max(left, 0), late,
                     f"{CURRENCY}{calculate_fine(b['due_date']):g}", "OVERDUE" if late else "ISSUED"))
    return rows


class MyBooksPage(BasePage):
    def __init__(self, parent, app):
        super().__init__(parent, app, "My Books", "Books you currently have, their due dates and fines")
        self.student_id = app.user["student_id"]
        self.summary = tk.Label(self, bg=C["bg"], font=(FONT, 11, "bold"), fg=C["amber"])
        self.summary.pack(anchor="w", pady=(0, 6))
        self.table = DataTable(self, CURRENT_COLS, height=16)
        self.table.pack(fill="both", expand=True)
        self.refresh()

    def refresh(self):
        self.table.set_rows(current_books(self.student_id), tag_col=7)
        self.summary.config(text=f"Total pending fine: {CURRENCY}{pending_fine(self.student_id):g}")
