"""Borrowing history for a student."""
from database.database import query
from utils.constants import CURRENCY
from utils.ui import BasePage, DataTable

COLS = [("t", "Title", 260), ("a", "Author", 150), ("i", "Issued", 90), ("d", "Due", 90), ("r", "Returned", 90),
        ("f", "Fine", 70), ("p", "Payment", 80), ("s", "Status", 85)]


def history_rows(student_id):
    rows = []
    for b in query("SELECT bk.title, bk.author, b.issue_date, b.due_date, b.return_date, b.fine, b.status, "
                   "f.payment_status FROM borrowings b JOIN books bk ON bk.book_id = b.book_id "
                   "LEFT JOIN fines f ON f.transaction_id = b.transaction_id WHERE b.student_id = ? "
                   "ORDER BY b.transaction_id DESC", (student_id,)):
        rows.append((b["title"], b["author"], b["issue_date"], b["due_date"], b["return_date"],
                     f"{CURRENCY}{b['fine']:g}", b["payment_status"] or "-", b["status"]))
    return rows


class HistoryPage(BasePage):
    def __init__(self, parent, app):
        super().__init__(parent, app, "Borrowing History", "Everything you have borrowed and returned")
        self.student_id = app.user["student_id"]
        self.table = DataTable(self, COLS, height=18)
        self.table.pack(fill="both", expand=True)
        self.refresh()

    def refresh(self):
        self.table.set_rows(history_rows(self.student_id), tag_col=7)
