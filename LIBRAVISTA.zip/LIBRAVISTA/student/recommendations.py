"""'Recommended for You' screen."""
from services.recommendation_service import recommend_books
from utils.ui import BasePage, DataTable

COLS = [("t", "Title", 300), ("a", "Author", 170), ("c", "Category", 150), ("r", "Why recommended", 300)]


def recommendation_rows(student_id, limit=8):
    return [(r["title"], r["author"], r["category"], r["reason"]) for r in recommend_books(student_id, limit=limit)]


class RecommendationsPage(BasePage):
    def __init__(self, parent, app):
        super().__init__(parent, app, "⭐ Recommended for You",
                         "Based on your categories, authors, history and what others borrow most")
        self.student_id = app.user["student_id"]
        self.table = DataTable(self, COLS, height=14)
        self.table.pack(fill="both", expand=True)
        self.refresh()

    def refresh(self):
        self.table.set_rows(recommendation_rows(self.student_id))
