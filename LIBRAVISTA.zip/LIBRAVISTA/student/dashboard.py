"""Student dashboard."""
import tkinter as tk
from tkinter import ttk

from database.database import query
from services.fine_service import pending_fine
from services.notification_service import generate_notifications, get_notifications
from student.history import COLS as HISTORY_COLS, history_rows
from student.my_books import CURRENT_COLS, current_books
from student.recommendations import COLS as REC_COLS, recommendation_rows
from utils.constants import COLORS as C, CURRENCY
from utils.ui import BasePage, DataTable, stat_grid


class StudentDashboard(BasePage):
    def __init__(self, parent, app):
        super().__init__(parent, app, f"Welcome, {app.user['full_name']}", "Your library at a glance")
        self.student_id = app.user["student_id"]
        self.cards = tk.Frame(self, bg=C["bg"])
        self.cards.pack(fill="x")
        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill="both", expand=True, pady=10)
        self.tables = {}
        specs = [("current", "My Current Books", CURRENT_COLS), ("soon", "Due Soon", CURRENT_COLS),
                 ("rec", "Recommended Books", REC_COLS), ("hist", "Borrowing History", HISTORY_COLS),
                 ("notes", "Notifications", [("d", "Date", 140), ("m", "Message", 720)])]
        for key, title, cols in specs:
            frame = tk.Frame(self.tabs, bg=C["bg"], pady=8)
            table = DataTable(frame, cols, height=11)
            table.pack(fill="both", expand=True)
            self.tabs.add(frame, text=f" {title} ")
            self.tables[key] = table
        self.refresh()

    def refresh(self):
        sid = self.student_id
        counts = query("SELECT COUNT(*) AS total, SUM(status='RETURNED') AS returned FROM borrowings WHERE student_id = ?",
                       (sid,), one=True)
        current = current_books(sid)
        for child in self.cards.winfo_children():
            child.destroy()
        stat_grid(self.cards, [("Books Borrowed", counts["total"], C["primary"]),
                               ("Books Returned", counts["returned"] or 0, C["green"]),
                               ("Overdue Books", sum(1 for r in current if r[7] == "OVERDUE"), C["red"]),
                               ("Pending Fine", f"{CURRENCY}{pending_fine(sid):g}", C["amber"])])
        generate_notifications()
        self.tables["current"].set_rows(current, tag_col=7)
        self.tables["soon"].set_rows([r for r in current if r[7] != "OVERDUE" and r[4] <= 3], tag_col=7)
        self.tables["rec"].set_rows(recommendation_rows(sid))
        self.tables["hist"].set_rows(history_rows(sid), tag_col=7)
        self.tables["notes"].set_rows([tuple(n) for n in get_notifications(self.user, 50)])
