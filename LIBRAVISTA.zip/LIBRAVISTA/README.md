# LIBRAVISTA — Smart Library Management System
*Your Knowledge. Your Library. Your Future.*

A desktop library system built with **Python + Tkinter + SQLite** for colleges: books, members, issue/return, fines, recommendations, reports and role-based access (Admin / Librarian / Student).

## Features
- Login, student sign-up, forgot password, logout (PBKDF2-SHA256 salted hashing, parameterized SQL)
- Admin / Librarian / Student dashboards with cards and charts
- Book CRUD with ISBN validation, search (title, author, ISBN, category, publisher, shelf) and filters
- Status badges: AVAILABLE / LOW STOCK / ISSUED / OUT OF STOCK
- Issue/return with borrowing limit, due dates, automatic fine = overdue days x fine per day
- Rule-based "Recommended for You" (category, author, popularity) — no external AI
- In-app notifications, activity logs, CSV/Excel report export to `exports/`
- Admin settings: max books, borrowing days, fine per day

## Setup
Requires Python 3.9+ on Windows (Tkinter ships with the python.org installer).
```
pip install -r requirements.txt
python main.py
```
`library.db` is created with demo data on first run. Run tests: `python -m unittest tests.test_library`

## Demo accounts
| Role | Username | Password |
|---|---|---|
| Admin | admin | Admin@123 |
| Librarian | lib1 / lib2 | Lib@12345 |
| Student | stu1 ... stu5 (IDs S1001-S1005) | Student@123 |

Change these after the demo. Delete `library.db` to reset.

## Structure
`database/` (schema, connection, seed) · `auth/` (password, login, signup) · `services/` (fines, circulation, recommendations, notifications, reports) · `ui/` (app shell, pages, widgets) · `utils/` · `tests/` · `exports/`

## Database
users, students, librarians, books, borrowings, fines, notifications, settings, activity_logs (foreign keys enabled).

## Screenshots
_Add screenshots here._

## Future enhancements
Barcode scanning, email/SMS reminders, book reservations, cover images, PDF reports.
