import tkinter as tk
from tkinter import ttk, messagebox
from database.database import query, execute, log
from services import circulation_service as circ, fine_service as fines, report_service as rep
from services.notification_service import get_notifications
from services.recommendation_service import recommend
from auth.signup import register_librarian
from utils.constants import NAVY, BG
from utils.helpers import today
from ui.widgets import *

BOOK_FIELDS = [("isbn", "ISBN"), ("title", "Title"), ("author", "Author"), ("category", "Category"),
               ("publisher", "Publisher"), ("publication_year", "Year"), ("language", "Language"),
               ("quantity", "Quantity"), ("shelf_number", "Shelf No.")]

def _status(r):
    return circ.availability(r["quantity"], r["available_quantity"])

def dashboard(app, f):
    u = app.user; title(f, f"Welcome, {u['full_name']}")
    if u["role"] == "STUDENT":
        sid = u["ref_id"]
        active = query("SELECT * FROM borrowings WHERE student_id=? AND status='ISSUED'", (sid,))
        returned = query("SELECT COUNT(*) c FROM borrowings WHERE student_id=? AND status='RETURNED'", (sid,))[0]["c"]
        over = sum(1 for r in active if r["due_date"] < today())
        cards(f, [("Books Borrowed", len(active), "#2563eb"), ("Books Returned", returned, "#1a8f4a"),
                  ("Overdue Books", over, "#c62828"), ("Pending Fine", f"{fines.pending_fine(sid):.0f}", "#d98200")])
        subtitle(f, "Due Soon / Current Books")
        t = make_table(f, ("Title", "Due Date", "State"), (380, 120, 100), 4)
        fill(t, [(query("SELECT title FROM books WHERE book_id=?", (r["book_id"],))[0]["title"], r["due_date"],
                  "OVERDUE" if r["due_date"] < today() else "ISSUED") for r in active], 2)
        subtitle(f, "Recommended for You")
        t = make_table(f, ("Title", "Author", "Category"), (300, 180, 160), 4)
        fill(t, [(b["title"], b["author"], b["category"]) for b in recommend(sid, 4)])
        return
    q = lambda s: query(s)[0][0]
    cards(f, [("Total Books", q("SELECT COALESCE(SUM(quantity),0) FROM books"), "#2563eb"),
              ("Available", q("SELECT COALESCE(SUM(available_quantity),0) FROM books"), "#1a8f4a"),
              ("Issued", q("SELECT COUNT(*) FROM borrowings WHERE status='ISSUED'"), "#d98200"),
              ("Students", q("SELECT COUNT(*) FROM students"), NAVY),
              ("Librarians", q("SELECT COUNT(*) FROM librarians"), NAVY),
              ("Overdue", q("SELECT COUNT(*) FROM borrowings WHERE status='ISSUED' AND due_date<date('now')"), "#c62828"),
              ("Fines", f"{q('SELECT COALESCE(SUM(amount),0) FROM fines'):.0f}", "#c62828")])
    row = tk.Frame(f, bg=BG); row.pack(fill="x")
    bar_chart(row, "Books by category", [(r[0], r[1]) for r in query("SELECT category, COUNT(*) FROM books GROUP BY category")])
    bar_chart(row, "Monthly borrowing", [(r[0], r[1]) for r in query("SELECT strftime('%m/%y',issue_date), COUNT(*) FROM borrowings GROUP BY strftime('%Y-%m',issue_date)")], "#1a8f4a")
    row2 = tk.Frame(f, bg=BG); row2.pack(fill="x")
    bar_chart(row2, "Most borrowed books", [(r[0], r[1]) for r in query("SELECT b.title, COUNT(*) FROM borrowings br JOIN books b USING(book_id) GROUP BY b.book_id ORDER BY 2 DESC LIMIT 5")], "#d98200")
    bar_chart(row2, "Fines: paid vs pending", [(r[0], r[1]) for r in query("SELECT status, COALESCE(SUM(amount),0) FROM fines GROUP BY status")], "#c62828")
    subtitle(f, "Recently Added / Recently Returned")
    t = make_table(f, ("Recently Added", "Added", "Recently Returned", "Returned"), (230, 90, 230, 90), 4)
    added = query("SELECT title, added_date FROM books ORDER BY added_date DESC LIMIT 4")
    ret = query("SELECT b.title, br.return_date FROM borrowings br JOIN books b USING(book_id) WHERE return_date IS NOT NULL ORDER BY return_date DESC LIMIT 4")
    fill(t, [tuple(added[i]) + tuple(ret[i]) if i < len(added) and i < len(ret) else () for i in range(4)])

def books(app, f):
    role = app.user["role"]; title(f, "Books" if role != "STUDENT" else "Search Books")
    bar = tk.Frame(f, bg=BG); bar.pack(fill="x")
    sv, cv, av = tk.StringVar(), tk.StringVar(value="All"), tk.StringVar(value="All")
    ttk.Label(bar, text="Search:").pack(side="left"); ttk.Entry(bar, textvariable=sv, width=28).pack(side="left", padx=4)
    cats = ["All"] + [r[0] for r in query("SELECT DISTINCT category FROM books ORDER BY 1")]
    ttk.Combobox(bar, textvariable=cv, values=cats, width=18, state="readonly").pack(side="left", padx=4)
    ttk.Combobox(bar, textvariable=av, values=["All", "Available", "Issued"], width=10, state="readonly").pack(side="left", padx=4)
    tree = make_table(f, ("ID", "ISBN", "Title", "Author", "Category", "Shelf", "Qty", "Avail", "Status"),
                      (60, 120, 240, 150, 130, 70, 40, 45, 100), 14)
    def refresh(*_):
        like = f"%{sv.get().strip()}%"
        sql = ("SELECT * FROM books WHERE (title LIKE ? OR author LIKE ? OR isbn LIKE ? OR category LIKE ? "
               "OR publisher LIKE ? OR shelf_number LIKE ?)"); p = [like] * 6
        if cv.get() != "All": sql += " AND category=?"; p.append(cv.get())
        if av.get() == "Available": sql += " AND available_quantity>0"
        if av.get() == "Issued": sql += " AND available_quantity=0"
        fill(tree, [(b["book_id"], b["isbn"], b["title"], b["author"], b["category"], b["shelf_number"],
                     b["quantity"], b["available_quantity"], _status(b)) for b in query(sql, p)], 8)
    for var in (sv, cv, av): var.trace_add("write", refresh)
    refresh()
    def selected():
        s = tree.selection()
        if not s: raise LibraryError("Select a book first.")
        return tree.item(s[0])["values"][0]
    if role != "STUDENT":
        btns = tk.Frame(f, bg=BG); btns.pack(fill="x")
        ttk.Button(btns, text="Add Book", style="Accent.TButton", command=lambda: form_dialog(f, "Add Book", BOOK_FIELDS,
                   lambda d: (circ.save_book(d, app.user["username"]), refresh()))).pack(side="left", padx=3)
        def edit():
            bid = selected(); form_dialog(f, "Edit Book", BOOK_FIELDS,
                lambda d: (circ.save_book(d, app.user["username"], bid), refresh()), dict(query("SELECT * FROM books WHERE book_id=?", (bid,))[0]))
        ttk.Button(btns, text="Edit Selected", command=guard(edit)).pack(side="left", padx=3)
        if role == "ADMIN":
            def delete():
                bid = selected()
                if messagebox.askyesno("Confirm", f"Delete book {bid}?"):
                    circ.delete_book(bid, app.user["username"]); refresh()
            ttk.Button(btns, text="Delete Selected", command=guard(delete)).pack(side="left", padx=3)
    else:
        subtitle(f, "Recommended for You")
        t = make_table(f, ("Title", "Author", "Category"), (300, 180, 160), 3)
        fill(t, [(b["title"], b["author"], b["category"]) for b in recommend(app.user["ref_id"], 3)])

def students(app, f):
    title(f, "Students")
    t = make_table(f, ("ID", "Name", "Email", "Phone", "Department", "Year", "Status"), (70, 150, 180, 100, 160, 50, 80), 14)
    load = lambda: fill(t, [tuple(r) for r in query("SELECT student_id,full_name,email,phone,department,year,status FROM students")])
    load()
    def toggle():
        s = t.selection()
        if not s: raise LibraryError("Select a student first.")
        sid, st = t.item(s[0])["values"][0], t.item(s[0])["values"][6]
        new = "BLOCKED" if st == "ACTIVE" else "ACTIVE"
        uid = query("SELECT user_id FROM students WHERE student_id=?", (sid,))[0][0]
        execute("UPDATE students SET status=? WHERE student_id=?", (new, sid)); execute("UPDATE users SET status=? WHERE user_id=?", (new, uid))
        log(app.user["username"], f"Student {sid} set to {new}"); load()
    ttk.Button(f, text="Block / Unblock Selected", command=guard(toggle)).pack(anchor="w")

def librarians(app, f):
    title(f, "Librarians")
    t = make_table(f, ("ID", "Name", "Email", "Phone", "Joined", "Status"), (50, 160, 200, 110, 100, 80), 10)
    load = lambda: fill(t, [tuple(r) for r in query("SELECT librarian_id,full_name,email,phone,joining_date,status FROM librarians")])
    load()
    fields = [("full_name", "Full Name"), ("email", "Email"), ("phone", "Phone"), ("username", "Username"), ("password", "Password", True)]
    ttk.Button(f, text="Add Librarian", style="Accent.TButton", command=lambda: form_dialog(f, "Add Librarian", fields,
               lambda d: (register_librarian(d, app.user["username"]), load()))).pack(anchor="w")

def issue(app, f):
    title(f, "Issue / Return")
    bar = tk.Frame(f, bg=BG); bar.pack(fill="x")
    bv, sv = tk.StringVar(), tk.StringVar()
    for label, var in (("Book ID", bv), ("Student ID", sv)):
        ttk.Label(bar, text=label).pack(side="left"); ttk.Entry(bar, textvariable=var, width=12).pack(side="left", padx=5)
    tree = make_table(f, ("Txn", "Book", "Title", "Student", "Issued", "Due", "State"), (50, 60, 250, 70, 90, 90, 90), 14)
    def load():
        fill(tree, [(r["transaction_id"], r["book_id"], r["title"], r["student_id"], r["issue_date"], r["due_date"],
                     "OVERDUE" if r["due_date"] < today() else "ISSUED") for r in
                    query("SELECT br.*, b.title FROM borrowings br JOIN books b USING(book_id) WHERE br.status='ISSUED' ORDER BY due_date")], 6)
    def do_issue():
        messagebox.showinfo("Issued", circ.issue_book(bv.get(), sv.get(), app.user["username"])); load()
    def do_return():
        s = tree.selection()
        if not s: raise LibraryError("Select a transaction to return.")
        messagebox.showinfo("Returned", circ.return_book(tree.item(s[0])["values"][0], app.user["username"])); load()
    ttk.Button(bar, text="Issue Book", style="Accent.TButton", command=guard(do_issue)).pack(side="left", padx=6)
    ttk.Button(bar, text="Return Selected", command=guard(do_return)).pack(side="left")
    load()

def fines_page(app, f, only_overdue=False):
    title(f, "Overdue Books" if only_overdue else "Fines")
    if only_overdue:
        t = make_table(f, ("Txn", "Title", "Student", "Due", "Overdue Days", "Fine Per Day", "Total Fine"), (50, 250, 70, 90, 100, 90, 90), 14)
        rows = []
        for r in query("SELECT br.*, b.title FROM borrowings br JOIN books b USING(book_id) WHERE br.status='ISSUED' AND due_date<date('now')"):
            d, fn = fines.calc_fine(r["due_date"]); rows.append((r["transaction_id"], r["title"], r["student_id"], r["due_date"], d, fines.get_setting("fine_per_day"), fn))
        fill(t, rows); return
    t = make_table(f, ("Fine", "Txn", "Student", "Overdue Days", "Per Day", "Total", "Payment"), (50, 50, 80, 100, 80, 90, 90), 14)
    load = lambda: fill(t, [tuple(r) for r in query("SELECT f.fine_id,f.transaction_id,b.student_id,f.overdue_days,f.fine_per_day,f.amount,f.status FROM fines f JOIN borrowings b USING(transaction_id)")], 6)
    load()
    def pay():
        s = t.selection()
        if not s: raise LibraryError("Select a fine first.")
        fines.mark_paid(t.item(s[0])["values"][0], app.user["username"]); load()
    ttk.Button(f, text="Mark Selected as PAID", style="Accent.TButton", command=guard(pay)).pack(anchor="w")

def overdue(app, f): fines_page(app, f, True)

def reports(app, f):
    title(f, "Reports")
    name = tk.StringVar(value="All Books")
    ttk.Combobox(f, textvariable=name, values=list(rep.REPORTS), state="readonly", width=30).pack(anchor="w")
    t = make_table(f, ("Preview",), (900,), 12)
    def preview(*_):
        rows = query(rep.REPORTS[name.get()]); t["columns"] = list(rows[0].keys()) if rows else ["Preview"]
        for c in t["columns"]: t.heading(c, text=c); t.column(c, width=130)
        fill(t, [tuple(r) for r in rows])
    name.trace_add("write", preview); preview()
    def export(fmt):
        path = rep.export(name.get(), fmt); log(app.user["username"], f"Exported {name.get()} ({fmt})")
        messagebox.showinfo("Exported", f"Saved to:\n{path}")
    bar = tk.Frame(f, bg=BG); bar.pack(anchor="w")
    ttk.Button(bar, text="Export CSV", command=guard(lambda: export("csv"))).pack(side="left", padx=3)
    ttk.Button(bar, text="Export Excel", command=guard(lambda: export("xlsx"))).pack(side="left", padx=3)

def notifications(app, f):
    title(f, "Notifications")
    lb = tk.Listbox(f, font=("Segoe UI", 10), height=18)
    lb.pack(fill="both", expand=True)
    for m in get_notifications(app.user): lb.insert("end", "  " + m)

def settings(app, f):
    title(f, "Settings"); vars_ = {}
    for key, label in (("max_books", "Max books per student"), ("loan_days", "Borrowing days"), ("fine_per_day", "Fine per day")):
        row = tk.Frame(f, bg=BG); row.pack(anchor="w", pady=4)
        ttk.Label(row, text=label, width=24).pack(side="left")
        vars_[key] = tk.StringVar(value=str(fines.get_setting(key, str))); ttk.Entry(row, textvariable=vars_[key], width=10).pack(side="left")
    def save():
        fines.update_settings({k: v.get() for k, v in vars_.items()}, app.user["username"]); messagebox.showinfo("Saved", "Settings updated.")
    ttk.Button(f, text="Save Settings", style="Accent.TButton", command=guard(save)).pack(anchor="w", pady=8)

def logs(app, f):
    title(f, "Activity Logs")
    t = make_table(f, ("Time", "User", "Action"), (140, 100, 500), 18)
    fill(t, [(r["timestamp"], r["user"], r["action"]) for r in query("SELECT * FROM activity_logs ORDER BY id DESC LIMIT 300")])

def mybooks(app, f):
    title(f, "My Books")
    t = make_table(f, ("Title", "Issued", "Due", "Overdue Days", "Fine", "State"), (280, 90, 90, 100, 70, 90), 12)
    rows = []
    for r in query("SELECT br.*, b.title FROM borrowings br JOIN books b USING(book_id) WHERE student_id=? AND status='ISSUED'", (app.user["ref_id"],)):
        d, fn = fines.calc_fine(r["due_date"]); rows.append((r["title"], r["issue_date"], r["due_date"], d, fn, "OVERDUE" if d else "ISSUED"))
    fill(t, rows, 5)
    tk.Label(f, text=f"Total pending fine: {fines.pending_fine(app.user['ref_id']):.0f}", bg=BG, fg="#c62828", font=("Segoe UI", 11, "bold")).pack(anchor="w")

def recs(app, f):
    title(f, "Recommended for You")
    t = make_table(f, ("Title", "Author", "Category", "Shelf"), (300, 180, 150, 80), 12)
    fill(t, [(b["title"], b["author"], b["category"], b["shelf_number"]) for b in recommend(app.user["ref_id"], 10)])
    tk.Label(f, text="Based on your categories, authors and the most borrowed books.", bg=BG).pack(anchor="w")

def history(app, f):
    title(f, "Borrowing History")
    t = make_table(f, ("Title", "Issued", "Due", "Returned", "Fine", "Status"), (280, 90, 90, 90, 70, 90), 16)
    fill(t, [(r["title"], r["issue_date"], r["due_date"], r["return_date"] or "-", r["fine"], r["status"]) for r in
             query("SELECT br.*, b.title FROM borrowings br JOIN books b USING(book_id) WHERE student_id=? ORDER BY issue_date DESC", (app.user["ref_id"],))], 5)

def profile(app, f):
    title(f, "Profile"); s = query("SELECT * FROM students WHERE student_id=?", (app.user["ref_id"],))[0]
    for k in ("student_id", "full_name", "email", "phone", "department", "year", "registration_date", "status"):
        tk.Label(f, text=f"{k.replace('_', ' ').title()}:  {s[k]}", bg=BG, font=("Segoe UI", 11)).pack(anchor="w", pady=2)

PAGES = {"dashboard": (dashboard, ("ADMIN", "LIBRARIAN", "STUDENT")), "books": (books, ("ADMIN", "LIBRARIAN", "STUDENT")),
         "students": (students, ("ADMIN", "LIBRARIAN")), "librarians": (librarians, ("ADMIN",)),
         "issue": (issue, ("ADMIN", "LIBRARIAN")), "fines": (fines_page, ("ADMIN", "LIBRARIAN")),
         "overdue": (overdue, ("ADMIN", "LIBRARIAN")), "reports": (reports, ("ADMIN", "LIBRARIAN")),
         "notifications": (notifications, ("ADMIN", "STUDENT")), "settings": (settings, ("ADMIN",)),
         "logs": (logs, ("ADMIN",)), "mybooks": (mybooks, ("STUDENT",)), "recs": (recs, ("STUDENT",)),
         "history": (history, ("STUDENT",)), "profile": (profile, ("STUDENT",))}
