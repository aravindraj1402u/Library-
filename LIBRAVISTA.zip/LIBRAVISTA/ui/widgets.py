import tkinter as tk
from tkinter import ttk, messagebox
from utils.constants import NAVY, GOLD, BG, WHITE
from utils.helpers import LibraryError

TAGS = {"AVAILABLE": "#1a8f4a", "LOW STOCK": "#d98200", "ISSUED": "#2563eb", "OUT OF STOCK": "#c62828",
        "OVERDUE": "#c62828", "PAID": "#1a8f4a", "PENDING": "#d98200", "RETURNED": "#1a8f4a"}

def setup_style(root):
    s = ttk.Style(root); s.theme_use("clam")
    s.configure("Treeview", rowheight=26, font=("Segoe UI", 10))
    s.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"), background=NAVY, foreground=WHITE)
    s.configure("Accent.TButton", background=GOLD, foreground=NAVY, font=("Segoe UI", 10, "bold"), padding=6)
    s.configure("TButton", padding=5)

def guard(fn):
    """Wrap a button action so errors become friendly messages, never tracebacks."""
    def wrapper(*a):
        try:
            fn(*a)
        except LibraryError as e:
            messagebox.showwarning("LIBRAVISTA", str(e))
        except Exception:
            messagebox.showerror("LIBRAVISTA", "Something went wrong. Please try again.")
    return wrapper

def title(parent, text):
    tk.Label(parent, text=text, font=("Segoe UI", 18, "bold"), bg=BG, fg=NAVY).pack(anchor="w", pady=(0, 8))

def subtitle(parent, text):
    tk.Label(parent, text=text, font=("Segoe UI", 12, "bold"), bg=BG, fg=NAVY).pack(anchor="w", pady=(10, 2))

def make_table(parent, cols, widths=None, height=10):
    fr = tk.Frame(parent, bg=BG); fr.pack(fill="both", expand=True, pady=4)
    tree = ttk.Treeview(fr, columns=cols, show="headings", height=height)
    for i, c in enumerate(cols):
        tree.heading(c, text=c); tree.column(c, width=widths[i] if widths else 110, anchor="w")
    sb = ttk.Scrollbar(fr, orient="vertical", command=tree.yview); tree.configure(yscrollcommand=sb.set)
    tree.pack(side="left", fill="both", expand=True); sb.pack(side="right", fill="y")
    for k, c in TAGS.items(): tree.tag_configure(k, foreground=c)
    return tree

def fill(tree, rows, tag_col=None):
    tree.delete(*tree.get_children())
    for r in rows:
        vals = tuple(r)
        tree.insert("", "end", values=vals, tags=((str(vals[tag_col]),) if tag_col is not None else ()))

def cards(parent, items):
    row = tk.Frame(parent, bg=BG); row.pack(fill="x", pady=4)
    for label, value, color in items:
        c = tk.Frame(row, bg=WHITE, highlightbackground="#dfe3ec", highlightthickness=1, padx=14, pady=10)
        c.pack(side="left", padx=5, pady=4)
        tk.Label(c, text=str(value), font=("Segoe UI", 20, "bold"), bg=WHITE, fg=color).pack()
        tk.Label(c, text=label, font=("Segoe UI", 9), bg=WHITE, fg="#555").pack()

def bar_chart(parent, heading, data, color="#2563eb", w=330, h=190):
    c = tk.Canvas(parent, width=w, height=h, bg=WHITE, highlightbackground="#dfe3ec")
    c.pack(side="left", padx=5, pady=4)
    c.create_text(8, 10, anchor="w", text=heading, font=("Segoe UI", 10, "bold"), fill=NAVY)
    if not data: return
    top = max(v for _, v in data) or 1; bw = (w - 20) / len(data)
    for i, (label, val) in enumerate(data):
        x = 10 + i * bw; y = h - 30 - (val / top) * (h - 70)
        c.create_rectangle(x + 4, y, x + bw - 4, h - 30, fill=color, outline="")
        c.create_text(x + bw / 2, y - 8, text=f"{val:g}", font=("Segoe UI", 8))
        c.create_text(x + bw / 2, h - 16, text=str(label)[:9], font=("Segoe UI", 7))

def form_dialog(parent, heading, fields, on_save, initial=None):
    """fields: (key, label[, secret]). on_save gets a dict and may raise LibraryError."""
    top = tk.Toplevel(parent); top.title(heading); top.grab_set(); top.configure(bg=BG)
    vars_ = {}
    for i, fd in enumerate(fields):
        ttk.Label(top, text=fd[1]).grid(row=i, column=0, sticky="w", padx=12, pady=4)
        var = tk.StringVar(value=str((initial or {}).get(fd[0], "") or "")); vars_[fd[0]] = var
        ttk.Entry(top, textvariable=var, width=34, show="*" if len(fd) > 2 and fd[2] else "").grid(row=i, column=1, padx=12, pady=4)
    def save():
        try:
            on_save({k: x.get().strip() for k, x in vars_.items()}); top.destroy()
        except LibraryError as e:
            messagebox.showwarning("Please check", str(e), parent=top)
        except Exception:
            messagebox.showerror("Error", "Could not save. Please try again.", parent=top)
    ttk.Button(top, text="Save", style="Accent.TButton", command=save).grid(row=len(fields), column=1, sticky="e", padx=12, pady=10)
