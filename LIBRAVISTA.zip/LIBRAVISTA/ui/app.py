import tkinter as tk
from tkinter import ttk, messagebox
from auth.login import authenticate, reset_password
from auth.signup import register_student
from database.database import log
from ui import pages
from ui.widgets import setup_style, guard, form_dialog
from utils.constants import *

MENUS = {
 "ADMIN": [("Dashboard", "dashboard"), ("Books", "books"), ("Students", "students"), ("Librarians", "librarians"),
           ("Issue / Return", "issue"), ("Fines", "fines"), ("Reports", "reports"), ("Notifications", "notifications"),
           ("Settings", "settings"), ("Activity Logs", "logs")],
 "LIBRARIAN": [("Dashboard", "dashboard"), ("Books", "books"), ("Issue / Return", "issue"), ("Students", "students"),
               ("Overdue", "overdue"), ("Fines", "fines"), ("Reports", "reports")],
 "STUDENT": [("Dashboard", "dashboard"), ("Search Books", "books"), ("My Books", "mybooks"), ("Recommendations", "recs"),
             ("History", "history"), ("Notifications", "notifications"), ("Profile", "profile")]}

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"{APP_NAME} - Smart Library Management System"); self.geometry("1150x700"); self.minsize(1000, 620)
        setup_style(self); self.user = None; self.root_frame = None
        self.show_login()

    def _reset(self):
        if self.root_frame: self.root_frame.destroy()
        self.root_frame = tk.Frame(self); self.root_frame.pack(fill="both", expand=True)
        return self.root_frame

    # ---------- login ----------
    def show_login(self):
        self.user = None; root = self._reset()
        left = tk.Frame(root, bg=NAVY, width=470); left.pack(side="left", fill="y"); left.pack_propagate(False)
        c = tk.Canvas(left, width=200, height=150, bg=NAVY, highlightthickness=0); c.pack(pady=(110, 10))
        c.create_polygon(20, 40, 100, 60, 100, 140, 20, 120, fill=GOLD, outline="")      # left page
        c.create_polygon(180, 40, 100, 60, 100, 140, 180, 120, fill="#f6d27a", outline="")  # right page
        c.create_polygon(100, 20, 118, 8, 136, 20, 118, 32, fill="white", outline="")       # graduation star
        tk.Label(left, text=APP_NAME, font=("Georgia", 32, "bold"), bg=NAVY, fg=WHITE).pack()
        tk.Label(left, text="Smart Library Management System", font=("Segoe UI", 11), bg=NAVY, fg=GOLD).pack(pady=4)
        tk.Label(left, text=TAGLINE, font=("Georgia", 11, "italic"), bg=NAVY, fg="#c9d3e6", wraplength=380).pack(pady=20)
        right = tk.Frame(root, bg=WHITE); right.pack(side="left", fill="both", expand=True)
        box = tk.Frame(right, bg=WHITE); box.place(relx=0.5, rely=0.5, anchor="center")
        tk.Label(box, text="Sign in", font=("Segoe UI", 24, "bold"), bg=WHITE, fg=NAVY).grid(row=0, column=0, columnspan=2, pady=14)
        uv, pv, rv = tk.StringVar(), tk.StringVar(), tk.StringVar(value="STUDENT")
        for i, (lab, var, secret) in enumerate((("Username / Email", uv, False), ("Password", pv, True)), 1):
            tk.Label(box, text=lab, bg=WHITE).grid(row=i, column=0, sticky="w", pady=6)
            ttk.Entry(box, textvariable=var, width=30, show="*" if secret else "").grid(row=i, column=1, padx=8)
        tk.Label(box, text="Role", bg=WHITE).grid(row=3, column=0, sticky="w", pady=6)
        ttk.Combobox(box, textvariable=rv, values=ROLES, state="readonly", width=28).grid(row=3, column=1)
        def login():
            self.user = authenticate(uv.get(), pv.get(), rv.get()); self.show_main()
        ttk.Button(box, text="Login", style="Accent.TButton", command=guard(login)).grid(row=4, column=0, columnspan=2, sticky="ew", pady=14)
        self.bind("<Return>", lambda e: guard(login)())
        links = tk.Frame(box, bg=WHITE); links.grid(row=5, column=0, columnspan=2)
        ttk.Button(links, text="Sign Up (Students)", command=self.signup_dialog).pack(side="left", padx=4)
        ttk.Button(links, text="Forgot Password", command=self.forgot_dialog).pack(side="left", padx=4)

    def signup_dialog(self):
        fields = [("full_name", "Full Name"), ("student_id", "Student ID"), ("email", "Email"), ("phone", "Phone"),
                  ("department", "Department"), ("year", "Year (1-4)"), ("username", "Username"),
                  ("password", "Password", True), ("confirm", "Confirm Password", True)]
        def save(d):
            register_student(d); messagebox.showinfo("LIBRAVISTA", "Account created successfully.")
        form_dialog(self, "Student Sign Up", fields, save)

    def forgot_dialog(self):
        def save(d):
            reset_password(d["username"], d["email"], d["password"]); messagebox.showinfo("LIBRAVISTA", "Password updated. Please log in.")
        form_dialog(self, "Reset Password", [("username", "Username"), ("email", "Registered Email"), ("password", "New Password", True)], save)

    # ---------- main shell ----------
    def show_main(self):
        self.unbind("<Return>"); root = self._reset()
        side = tk.Frame(root, bg=NAVY, width=210); side.pack(side="left", fill="y"); side.pack_propagate(False)
        tk.Label(side, text=APP_NAME, font=("Georgia", 18, "bold"), bg=NAVY, fg=GOLD).pack(pady=(20, 2))
        tk.Label(side, text=f"{self.user['role']}  |  {self.user['username']}", bg=NAVY, fg="#c9d3e6", font=("Segoe UI", 9)).pack(pady=(0, 16))
        for label, key in MENUS[self.user["role"]]:
            tk.Button(side, text="  " + label, anchor="w", bg=NAVY, fg=WHITE, activebackground=GOLD, relief="flat",
                      font=("Segoe UI", 11), command=lambda k=key: self.show_page(k)).pack(fill="x", ipady=5)
        tk.Button(side, text="  Logout", anchor="w", bg="#7a1f1f", fg=WHITE, relief="flat", font=("Segoe UI", 11),
                  command=self.logout).pack(side="bottom", fill="x", ipady=6)
        self.content = tk.Frame(root, bg=BG, padx=18, pady=14); self.content.pack(side="left", fill="both", expand=True)
        self.show_page("dashboard")

    def show_page(self, key):
        func, allowed = pages.PAGES[key]
        if self.user["role"] not in allowed:       # role-based access check
            messagebox.showwarning("Access denied", "You do not have permission to open this page."); return
        for w in self.content.winfo_children(): w.destroy()
        try:
            func(self, self.content)
        except Exception:
            messagebox.showerror("LIBRAVISTA", "Could not load this page.")

    def logout(self):
        if messagebox.askyesno("Logout", "Do you want to log out?"):
            log(self.user["username"], "Logged out"); self.show_login()
